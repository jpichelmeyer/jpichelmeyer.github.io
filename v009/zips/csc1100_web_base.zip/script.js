// Data storage
const spotifyData = {
    "trackName": "Blinding Lights",
    "artist": "The Weeknd",
    "album": "After Hours",
    "isPlaying": true
}

// Object reference
const rotationThing = document.getElementById('rotation-thing');

// Global variables
let time = 0;
const maxAngle = 2;
const speed = 0.03;

// Function defintion(s)
function wiggle(){
    time += speed;
    const currentRotation = Math.sin(time) * maxAngle;
    rotationThing.style.transform = `rotate(${currentRotation}deg)`;
    requestAnimationFrame(wiggle);
}

function populateSpotifyData(spotData){
    const container = document.getElementById('rotation-thing');
    if (spotData.isPlaying){
        container.innerHTML = `
            <strong>Now Playing:</strong><br>
            "${spotData.trackName}" by ${spotData.artist}<br>
            <small>Albumn: ${spotData.album}</small>
        `;
    } else {
        container.innerHTML = "Nothing playing right now";
    }
}

// Code execution
wiggle();
populateSpotifyData(spotifyData);
