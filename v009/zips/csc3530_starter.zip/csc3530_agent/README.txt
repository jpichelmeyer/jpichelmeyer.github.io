CSC 3530 starter files
======================

1. Make a project folder, e.g. csc3530_agent/
2. Put arc_utils.py and arc_agent.py in it.
3. Download the ARC-AGI-1 data from https://github.com/fchollet/ARC-AGI
   (green Code button -> Download ZIP) and copy its data/ folder into
   your project folder, so you have data/training and data/evaluation.
4. Open arc_agent.py in Thonny and press Run. You should see
   "solved 7 of 400 training tasks".

arc_utils.py  helpers: load tasks, print grids, find objects, transforms
arc_agent.py  the week 1 SAM agent you will grow all semester
