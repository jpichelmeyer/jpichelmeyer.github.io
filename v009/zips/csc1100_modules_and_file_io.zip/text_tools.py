"""
A small module of functions for working with plain text.
"""

# For stripping off punctuation from text
PUNCTUATION = ".,;:!?\"'()-"


def clean_word(word):
    """
    Return the word in lowercase with surrounding punctuation removed.
    """
    return word.strip(PUNCTUATION).lower()


def count_lines(text):
    """
    Return the number of non-blank lines in a string of text.
    """
    count = 0
    for line in text.splitlines():
        if line.strip() != "":
            count += 1
    return count


def count_words(text):
    """
    Return the number of words in a string of text.
    """
    return len(text.split())


def word_frequencies(text):
    """
    Return a dictionary mapping each cleaned word to how many times it appears.
    """
    freqs = {}
    for word in text.split():
        word = clean_word(word)
        if word == "":
            continue
        freqs[word] = freqs.get(word, 0) + 1
    return freqs


def most_common_words(text, n=5):
    """
    Return a list of the n most common (word, count) pairs, most common first.
    """
    freqs = word_frequencies(text)
    pairs = list(freqs.items())
    pairs.sort(key=lambda pair: pair[1], reverse=True)
    return pairs[:n]


def longest_word(text):
    """
    Return the longest cleaned word in the text (the first one if there's a tie).
    """
    longest = ""
    for word in text.split():
        word = clean_word(word)
        if len(word) > len(longest):
            longest = word
    return longest


def shout(text):
    """
    Return the text in all capital letters.
    """
    return text.upper()


def number_lines(text):
    """
    Return the text with a line number added to the front of each line.

    "a\\nb" --> "1: a\\n2: b"
    
    """
    numbered = []
    for i, line in enumerate(text.splitlines(), start=1):
        numbered.append(f"{i}: {line}")
    return "\n".join(numbered)
