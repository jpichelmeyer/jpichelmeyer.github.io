"""
A small module of functions for working with student scores.
"""


def parse_line(line):
    """
    Turn a line like "Ada Lovelace,92" into a tuple ("Ada Lovelace", 92).

    Returns None if the line is blank or is the header line.
    """
    line = line.strip()
    if line == "" or line.lower().startswith("name"):
        return None
    name, score = line.split(",")
    return name.strip(), int(score)


def average(scores):
    """
    Return the mean of a list of numbers, rounded to 1 decimal place.
    """
    if len(scores) == 0:
        return 0
    return round(sum(scores) / len(scores), 1)


def median(scores):
    """
    Return the median of a list of numbers.
    """
    ordered = sorted(scores)
    n = len(ordered)
    if n == 0:
        return 0
    middle = n // 2
    if n % 2 == 1:
        return ordered[middle]
    return (ordered[middle - 1] + ordered[middle]) / 2


def letter_grade(score):
    """
    Return the letter grade (A, B, C, D, or F) for a numeric score.
    """
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


def curve(score, points=5, maximum=100):
    """
    Add curve points to a score without going over the maximum.
    """
    return min(score + points, maximum)


def passed(score, passing=60):
    """
    Return True if the score is at or above the passing mark.
    """
    return score >= passing


def format_report_line(name, score):
    """
    Return a neatly formatted line like: 
    
        "Ada Lovelace         92  A"
    
    """
    return f"{name:<20} {score:>3}  {letter_grade(score)}"
