extends Node2D
class_name Agent

@export var AgentGrid:Grid
@export var start_grid_pos:Vector2i = Vector2i(0,0)

@onready var AgentDecider:Decider = get_node("Decider")

func _ready():	
	
	# Put agent at a starting position in the grid
	if AgentGrid is Grid:
		if start_grid_pos in AgentGrid.grid:
			self.global_position = AgentGrid.grid[start_grid_pos][AgentGrid.key_world_pos]
	
	# Test BFS
	if AgentDecider is Decider:
		AgentDecider._shortest_grid_path_to_goal(AgentGrid)
