extends Node
class_name Decider

func _shortest_grid_path_to_goal(PassedGrid:Grid) -> Array:
	
	# Initialize
	var shortest_path = []
	
	# Perform BFS
	if PassedGrid is Grid:
		
		# Determine grid coords of start position
		var Parent = get_parent()
		var grid_pos_start = PassedGrid.get_grid_pos(Parent.global_position)
		print("grid_pos_start: ", grid_pos_start)
		
		# Determine grid coords of goal position
		var grid_pos_goal = null
		for grid_pos in PassedGrid.grid:
			if PassedGrid.is_goal(grid_pos):
				grid_pos_goal = grid_pos
				break
		print("grid_pos_goal : ", grid_pos_goal)
		
		# If start and goal grid coords are found, perform BFS
		if grid_pos_goal is Vector2i and grid_pos_start is Vector2i:
			print("grid_pos_start: ", grid_pos_start)
			print("grid_pos_goal : ", grid_pos_goal)
		
	# Return
	return shortest_path
