extends CharacterBody2D
class_name Player

enum FACING {
	EAST,
	NORTH,
	SOUTH,
	WEST
}
var facing:FACING = FACING.SOUTH
const facing_postfix = {
	FACING.EAST: "e",
	FACING.NORTH: "n",
	FACING.SOUTH: "s",
	FACING.WEST: "w"
}
var anim:String = "spin"

@onready var AnimPlayer:AnimationPlayer = get_node("AnimPlayer")

func _process(_delta):
	_update_facing()
	AnimPlayer.play(anim)

func _update_facing() -> void:
	if Input.is_action_pressed("move_up"):
		facing = FACING.NORTH
	if Input.is_action_pressed("move_down"):
		facing = FACING.SOUTH
	if Input.is_action_pressed("move_left"):
		facing = FACING.WEST
	if Input.is_action_pressed("move_right"):
		facing = FACING.EAST
	return

func get_facing_postfix() -> String:
	return "_" + facing_postfix[facing]
