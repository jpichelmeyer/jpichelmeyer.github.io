@icon("res://svg/bt_selector.svg")
extends BtComposite
class_name BtSelector

func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	# TODO 4: A Selector is like a logical OR: "try each option until one works."
	#   - Tick each child in order (left to right / top to bottom in the scene tree).
	#   - If a child returns SUCCESS or RUNNING, stop and return that same status
	#     right away. Later children are NOT ticked this frame.
	#   - If a child returns FAILURE, move on to the next child.
	#   - If every child failed, return FAILURE.
	#   (Rename `_actor`/`_delta` to `actor`/`delta` once you use them.)
	#   Expected after this step: still FAILURE, since the children aren't done yet.
	return STATUS.FAILURE
