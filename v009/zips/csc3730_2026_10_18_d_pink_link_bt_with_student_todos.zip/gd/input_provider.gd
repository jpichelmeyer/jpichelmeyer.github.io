extends Node

var dir_move:Vector2 = Vector2.ZERO

func _ready() -> void:
	print("Input provider class ready")

func _process(_delta:float) -> void:
	_update_dir_move()

func _update_dir_move() -> void:
	var dir_move_local:Vector2 = Vector2.ZERO
	if Input.is_action_pressed("move_up"):
		dir_move_local += Vector2( 0,-1)
	if Input.is_action_pressed("move_down"):
		dir_move_local += Vector2( 0, 1)
	if Input.is_action_pressed("move_left"):
		dir_move_local += Vector2(-1, 0)
	if Input.is_action_pressed("move_right"):
		dir_move_local += Vector2( 1, 0)
	if dir_move_local.length() > 0:
		dir_move_local = dir_move_local.normalized()
	dir_move = dir_move_local

func get_dir_move() -> Vector2:
	return dir_move

func is_moving() -> bool:
	var is_move = false
	if get_dir_move().length() > 0:
		is_move = true
	return is_move
