@icon("res://svg/bt_sequencer.svg")
extends BtComposite
class_name BtSequencer

func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	# TODO 6: A Sequencer is like a logical AND: "do every step, in order."
	#   - Tick each child in order.
	#   - If a child returns FAILURE or RUNNING, stop and return that same status
	#     right away.
	#   - If a child returns SUCCESS, move on to the next child.
	#   - If every child succeeded, return SUCCESS.
	#   Compare with your Selector from TODO 4. What is the only real difference?
	#   (Rename `_actor`/`_delta` to `actor`/`delta` once you use them.)
	#   Expected after this step: no visible change yet, because BtCheckMove
	#   still always fails, so the Selector falls through to BtIdle.
	return STATUS.FAILURE
