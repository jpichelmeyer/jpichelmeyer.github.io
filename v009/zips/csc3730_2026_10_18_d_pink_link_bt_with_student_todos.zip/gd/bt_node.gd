extends Node
class_name BtNode

# =============================================================================
# BEHAVIOR TREE LAB. ROADMAP
# Complete the TODOs in numerical order. After most steps you can press Play
# and watch the Output panel / the player to see what changed.
#
#   TODO 1   bt_node.gd       _child_check()      validate a node's child count
#   TODO 2a  bt_leaf.gd       _ready()            leaves have NO children
#   TODO 2b  bt_composite.gd  _ready()            composites have 1+ children
#   TODO 2c  bt_root.gd       _ready()            root has exactly ONE child
#   TODO 3   bt_root.gd       _physics_process()  tick the tree every frame
#   TODO 4   bt_selector.gd   tick()              "try children until one works"
#   TODO 5   bt_idle.gd       tick()              first action leaf (stand still)
#   TODO 6   bt_sequencer.gd  tick()              "do children in order"
#   TODO 7   bt_check_move.gd tick()              first condition leaf
#   TODO 8   bt_walk.gd       tick()              walk around!
#
# The tree we are building (see tscn/player.tscn):
#
#   BtRoot
#   └── BtSelector
#       ├── BtSequencer
#       │   ├── BtCheckMove   (condition: is a move key held?)
#       │   └── BtWalk        (action: move the player)
#       └── BtIdle            (action: stand still)
#
# While the tree isn't running, the player plays its default "spin" animation.
# =============================================================================

# Every tick() returns one of these. Read them carefully — the whole lab is
# about how parent nodes react to what their children return.
#   SUCCESS — "I finished, and it worked."
#   FAILURE — "I finished, and it didn't work / the condition is false."
#   RUNNING — "I'm not done yet; tick me again next frame."
enum STATUS {
	SUCCESS,
	FAILURE,
	RUNNING
}

var children:Array = []
var child_ct:int = 0
var active:bool = false

func _ready() -> void:
	active  = _child_check()

func _child_check(child_ct_min:int=1, child_ct_max:int=1) -> bool:
	# TODO 1: Check that this node has an allowed number of children.
	#   - Store this node's children in `children` and how many there are in `child_ct`.
	#       (Hint: get_children())
	#   - If there are fewer than child_ct_min, print "Error: Node has too few children".
	#   - If there are more than child_ct_max, print "Error: Node has too many children".
	#   - Return true if the count is within [child_ct_min, child_ct_max], false otherwise.
	#   The caller stores the result in `active`.
	return false

# Base tick. Every subclass overrides this with its own behavior.
func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	return STATUS.RUNNING
