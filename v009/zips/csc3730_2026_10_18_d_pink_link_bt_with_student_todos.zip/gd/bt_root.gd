@icon("res://svg/bt_root.svg")
extends BtNode
class_name BtRoot

const tick_announce_delta:float = 0.25
var tick_announce_timer:float = tick_announce_delta
var actor:CharacterBody2D
var OnlyChild:BtNode
var result:STATUS

func _ready() -> void:
	# TODO 2c: Set up the root.
	#   - The root's parent is the character this tree controls. Store it in `actor`.
	#   - The root must have EXACTLY one child. Use _child_check() and store the
	#     result in `active`.
	#   - If the root is active, store that one child in `OnlyChild`.
	pass

func _physics_process(_delta:float) -> void:
	# TODO 3: Tick the tree. This is the "heartbeat" that runs the whole tree.
	#   - Only do anything if the root is `active`.
	#   - Every physics frame, call tick() on OnlyChild (passing `actor` and the
	#     frame's delta) and store the returned STATUS in `result`.
	#   - Debug output: use `tick_announce_timer` to print
	#       "Root gets back status: " + result
	#     every `tick_announce_delta` seconds (count the timer down by delta and
	#     reset it when it goes below 0). Printing every frame floods the Output panel.
	#   (Rename `_delta` to `delta` once you use it.)
	#   Expected after this step: the status printed is 1 (FAILURE), because none
	#   of the nodes below the root work yet.
	pass
