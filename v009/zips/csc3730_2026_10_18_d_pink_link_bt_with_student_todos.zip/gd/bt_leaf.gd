@icon("res://svg/bt_leaf.svg")
extends BtNode
class_name BtLeaf

func _ready() -> void:
	# TODO 2a: A leaf is the bottom of the tree, so it must have NO children.
	#   Use _child_check() with the right min/max and store the result in `active`.
	pass

# Base leaf tick. Concrete leaves (BtIdle, BtCheckMove, BtWalk) override this.
func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	return STATUS.RUNNING
