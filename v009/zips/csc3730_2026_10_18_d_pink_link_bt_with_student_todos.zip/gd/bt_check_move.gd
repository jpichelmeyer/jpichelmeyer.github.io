extends BtLeaf
class_name BtCheckMove

func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	# TODO 7: Your first CONDITION leaf: "Is the player trying to move?"
	#   - Return SUCCESS if a movement key is held, otherwise FAILURE.
	#       (Hint: the InputProvider autoload; see gd/input_provider.gd)
	#   - Conditions answer a yes/no question immediately, so they never return
	#     RUNNING.
	#   Expected after this step: holding WASD makes the Sequencer move on to
	#   BtWalk (which still fails), so the Selector... what happens? Try it and
	#   explain why.
	return STATUS.FAILURE
