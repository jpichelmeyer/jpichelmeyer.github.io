extends BtLeaf
class_name BtIdle

func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	# TODO 5: Your first ACTION leaf: stand still.
	#   - Set the actor's animation to "idle" followed by its facing suffix.
	#       (Hint: actor.anim and actor.get_facing_postfix(); see player.gd)
	#   - Return RUNNING. Idling is never "finished"; it continues for as long as
	#     the tree keeps choosing it.
	#   (Rename `_actor` to `actor` once you use it.)
	#   Expected after this step: the player stops spinning and idles. The Root
	#   prints 2 (RUNNING). The keys still don't do anything.
	return STATUS.FAILURE
