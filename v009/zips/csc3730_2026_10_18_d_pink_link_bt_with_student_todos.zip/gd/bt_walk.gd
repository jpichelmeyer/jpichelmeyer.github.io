extends BtLeaf
class_name BtWalk

var SPD_MOVE:float = 70.0

func tick(_actor:CharacterBody2D, _delta:float) -> STATUS:
	# TODO 8: Walk!
	#   - Set the actor's animation to "walk" followed by its facing suffix.
	#   - Set actor.velocity to SPD_MOVE times the move direction from InputProvider.
	#       Careful: velocity is in pixels per SECOND, and move_and_slide() applies
	#       delta for you. Do NOT multiply by delta yourself.
	#   - Call actor.move_and_slide().
	#   - Return RUNNING (walking continues for as long as the key is held).
	#   (Rename `_actor` to `actor` once you use it.)
	#   Expected after this step: WASD walks the player around, and it idles when
	#   you let go. Done!
	return STATUS.FAILURE
