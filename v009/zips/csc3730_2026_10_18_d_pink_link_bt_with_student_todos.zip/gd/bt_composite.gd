@icon("res://svg/bt_composite.svg")
extends BtNode
class_name BtComposite

# Composites (BtSelector, BtSequencer) can store each child's result here.
var child_result:STATUS

func _ready() -> void:
	# TODO 2b: A composite combines its children, so it needs AT LEAST one child
	#   (use 100 as a generous maximum). Use _child_check() and store the result
	#   in `active`.
	pass
