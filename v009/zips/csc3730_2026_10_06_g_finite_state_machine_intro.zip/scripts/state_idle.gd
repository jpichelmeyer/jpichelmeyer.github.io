extends State
class_name StateIdle

'''
Play 'idle' animation
'''

func enter() -> void:
	# TODO 6: Announce state entry and play the "idle" animation via actor's AnimPlayer
	pass
