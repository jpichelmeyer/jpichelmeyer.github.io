extends Node2D
class_name Agent

@onready var AgentDecider:Decider = get_node("Decider")
@onready var AgentActuator:Actuator = get_node("Actuator")
@onready var AnimPlayer:AnimationPlayer = get_node("AnimPlayer")
@onready var StatusState:Label = get_node("HUD/StatusState")

func _process(_delta) -> void:
	if AgentDecider.state_current:
		StatusState.text = "Agent State: " + AgentDecider.state_current.name
