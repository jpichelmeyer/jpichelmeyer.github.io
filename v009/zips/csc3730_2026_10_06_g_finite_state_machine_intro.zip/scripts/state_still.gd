extends State
class_name StateStill

'''
Play the still animation
'''

func enter() -> void:
	# TODO 7: Announce state entry and play the "still" animation via actor's AnimPlayer
	pass
