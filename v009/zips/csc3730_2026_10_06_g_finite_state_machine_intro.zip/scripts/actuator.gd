extends Node2D
class_name Actuator
