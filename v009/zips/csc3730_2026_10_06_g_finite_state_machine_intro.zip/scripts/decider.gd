extends Node
class_name Decider

'''
Setup as a Finite State Machine
'''

@export var state_initial:State
var state_current:State
var states:Dictionary = {}

#--------------- Initial setup --------------------#
func _ready() -> void:
	
	# Wait for parent node to be ready
	await owner.ready
	
	# TODO 1: Iterate over all children of this node.
	# If a child is a 'State', add it to the 'states' dictionary (using lower_case names as keys)
	# and call its set_actor() method.
	pass

#--------------- Main loop --------------------#
func _process(delta:float) -> void:
	
	# TODO 2: Call update_process on the current state if it exists
	pass

func _physics_process(delta:float) -> void:
	# TODO 3: Call update_physics_process on the current state if it exists
	pass

#--------------- Input listening --------------------#
func _input(event:InputEvent):
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			transition_to("StateIdle")
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			transition_to("StateStill")

#--------------- Helper methods --------------------#

# Call this from any state to switch states
func transition_to(target_state_name: String) -> void:
	
	var state_new:State = states.get(target_state_name.to_lower())
	
	if not state_new or state_new == state_current:
		return
	
	# TODO 4: Complete the state transition procedure:
	# 1. Exit the current state (if one is currently active)
	# 2. Update state_current to point to state_new
	# 3. Enter the new current state
	pass
