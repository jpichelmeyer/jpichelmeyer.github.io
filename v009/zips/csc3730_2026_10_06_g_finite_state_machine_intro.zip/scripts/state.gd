extends Node
class_name State

var actor:Node2D

func _ready():
	set_actor()

#-------------- One time methods ---------------#
func set_actor():
	'''
	Agent
	|-- Decider
	    |-- State
	'''
	# TODO 5: Assign the 'actor' variable to point to the grandparent Node2D (Agent)
	pass

func enter() -> void:
	announce_enter()

func exit() -> void:
	announce_exit()

#-------------- Continuously looping methods ---------#
func update_process(_delta:float) -> void:
	pass

func update_physics_process(_delta:float) -> void:
	pass

#-------------- Announcement methods ---------#	
func announce_enter() -> void:
	print("\n...entering state", name, "...")

func announce_exit() -> void:
	print("...exiting state", name, "...")
