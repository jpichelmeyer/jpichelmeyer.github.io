extends Node2D
class_name Agent


@export var waypoint_rad:float = 5.0
@export var speed_move:float = 100.0
var waypoints:Array = []
var waypoint_following:bool = false

@export var AgentGrid:Grid
@export var start_grid_pos:Vector2i = Vector2i(0,0)

@onready var AgentDecider:Decider = get_node("Decider")
@onready var AgentActuator:Actuator = get_node("Actuator")
@onready var StatusWaypoint:Label = get_node("HUD/StatusWaypoint")

func _ready():	
	
	# Put agent at a starting position in the grid
	if AgentGrid is Grid:
		if start_grid_pos in AgentGrid.grid:
			self.global_position = AgentGrid.grid[start_grid_pos][AgentGrid.key_world_pos]
	
	# Initial BFS
	if AgentDecider is Decider:
		waypoints = AgentDecider.shortest_grid_path_to_goal(AgentGrid)
		print(waypoints)

func _process(delta:float):
	
	if Input.is_action_just_pressed("developer_press_A"):
		print("Agent says 'A'")
		waypoints = AgentDecider.shortest_grid_path_to_goal(AgentGrid)
	
	if Input.is_action_just_pressed("developer_press_B"):
		print("Agent says 'B'")
		waypoint_following = !waypoint_following
		waypoints = AgentDecider.shortest_grid_path_to_goal(AgentGrid)
	
	if waypoint_following and waypoints.size() < 1:
		waypoint_following = false
	
	if waypoint_following:
		waypoints = AgentActuator.follow_waypoints(waypoints, waypoint_rad, delta, speed_move)
	
	StatusWaypoint.text = "Waypoint following: " + str(waypoint_following)
