extends Node2D
class_name Grid

@export var width: int = 5
@export var height: int = 5
@export var cell_size: int = 64

var key_world_pos:String = "world_pos"
var key_is_goal:String = "is_goal"
var key_is_walkable:String = "is_walkable"

# Grid storage: Vector2i -> Dictionary (node data)
var grid: Dictionary = {}

const CARDINAL_DIRECTIONS = [
	Vector2i.UP, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT
]

func _ready() -> void:
	_create_grid()

func _input(event:InputEvent) -> void:
	
	#----------- LEFT CLICK: obstruct / unobstruct -------------#
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		# Get the grid position of the click
		var grid_pos = get_grid_pos(get_local_mouse_position())
		
		# Flip is walkable
		if grid.has(grid_pos):
			grid[grid_pos][key_is_walkable] = not grid[grid_pos][key_is_walkable]
			queue_redraw()
	
	#----------- RIGHT CLICK: update goal spot -------------#
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
		
		# Get grid position of the click
		var grid_pos = get_grid_pos(get_local_mouse_position())
		
		if grid.has(grid_pos):
			
			# Clear all goal cells
			for iterative_grid_pos in grid:
				grid[iterative_grid_pos][key_is_goal] = false
			
			grid[grid_pos][key_is_goal] = not grid[grid_pos][key_is_goal]
			queue_redraw()

func _draw() -> void:
	for x in range(width):
		for y in range(height):
			var grid_pos := Vector2i(x, y)
			var rect := Rect2(
				Vector2(x, y) * cell_size,
				Vector2(cell_size, cell_size)
			)
			
			#------ Fill blocked cells ----------#
			if not grid[grid_pos][key_is_walkable]:
				draw_rect(rect, Color(0.8, 0.2, 0.2, 0.5), true)
			
			#-------- Fill goal cell ------------#
			if grid[grid_pos][key_is_goal]:
				draw_rect(rect, Color(0.2, 0.8, 0.2, 0.5), true)
			
			#------- Draw grid lines ------------#
			draw_rect(rect, Color.WHITE, false, 2.0)

func _create_grid() -> void:
	
	grid.clear()
	for x in range(width):
		for y in range(height):
			
			#------- Determine the grid position (coords like (0,0), (1,0) )------#
			var grid_pos = Vector2i(x, y) # Needs to be Vector2i <--- i for int
			var local_is_goal = false # Make nothing the goal to start
			
			#------- Set the goal to be the last cell created, the bottom right corner -----#
			if x == width-1 and y == height-1:
				local_is_goal = true
			
			#------ Input an entry into the grid dictionary with                     ------#
			#------   key                :  value                                    ------#
			#------   grid_pos:Vector2i  :  a dictionary of properties for that cell ------#
			grid[grid_pos] = {
				key_is_walkable: true,
				key_is_goal: local_is_goal,
				key_world_pos: (Vector2(grid_pos) * cell_size) + Vector2(cell_size / 2.0, cell_size / 2.0)
			}

func get_grid_pos(world_pos: Vector2) -> Vector2i:
	return Vector2i((world_pos / cell_size).floor())

func get_world_pos(grid_pos:Vector2i) -> Vector2:
	return grid[grid_pos][key_world_pos]

func get_neighbors(grid_pos: Vector2i) -> Array[Vector2i]:
	var neighbors: Array[Vector2i] = []
	for dir in CARDINAL_DIRECTIONS:
		var target = grid_pos + dir
		if is_walkable(target):
			neighbors.append(target)
	return neighbors

func is_goal(grid_pos:Vector2i) -> bool:
	return grid.has(grid_pos) and grid[grid_pos][key_is_goal]

func is_walkable(grid_pos: Vector2i) -> bool:
	return grid.has(grid_pos) and grid[grid_pos][key_is_walkable]
