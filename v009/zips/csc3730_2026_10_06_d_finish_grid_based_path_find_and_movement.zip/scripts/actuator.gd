extends Node2D
class_name Actuator

var parent:Node2D

func _ready():
	parent = get_parent()

func follow_waypoints(passed_waypoints:Array, waypoint_radius:float=5.0, Delta:float=1e-3, passed_speed:float=5.0):
	if passed_waypoints.size() > 0:
		var current_target: Vector2 = passed_waypoints[0]
		
		# TODO: Move the parent's global position toward current_target using move_toward()
		# Hint: Distance per frame is Delta * passed_speed
		
		# TODO: Check if the parent is within waypoint_radius of current_target
		# If it is, pop the first waypoint off passed_waypoints
		
		pass
	
	return passed_waypoints
