extends Node
class_name Decider

func swap_grid_for_world(shortest_path:Array, PassedGrid:Grid) -> Array:
	for i in range(shortest_path.size()):
		shortest_path[i] = PassedGrid.get_world_pos(shortest_path[i])
	return shortest_path

func shortest_grid_path_to_goal(PassedGrid:Grid) -> Array:
	
	# Initialize
	var shortest_path:Array = []
	
	# Perform BFS
	if PassedGrid is Grid:
		
		# Determine grid coords of start position
		var Parent = get_parent()
		var grid_pos_start = PassedGrid.get_grid_pos(Parent.global_position)
		
		# Determine grid coords of goal position
		var grid_pos_goal = null
		for grid_pos in PassedGrid.grid:
			if PassedGrid.is_goal(grid_pos):
				grid_pos_goal = grid_pos
				break
		
		# If start and goal grid coords are found, perform BFS
		if grid_pos_goal is Vector2i and grid_pos_start is Vector2i and (grid_pos_goal != grid_pos_start):
			print("Start and goal coordinates found...")
			print("\tgrid_pos_start: ", grid_pos_start)
			print("\tgrid_pos_goal : ", grid_pos_goal)
			print("Performing Breadth-First Search algorithm...")
			
			var frontier:Array = []
			var visited:Array = []
			var visitation_links:Dictionary = {}
			
			frontier.append(grid_pos_start)
			
			var counter_while = 0
			while frontier.size() > 0:
				
				counter_while += 1
				if counter_while > 20:
					break
				
				# Pop front element off frontier
				var visiting = frontier.pop_front()
				print("\t...visiting ", visiting)
				
				# Add element to visited
				visited.append(visiting)
				
				var nbrs = PassedGrid.get_neighbors(visiting)
				for nbr in nbrs:
					
					# TODO: Check if the neighbor has NOT been visited and is NOT in frontier
					# 1. Append nbr to frontier
					# 2. Record the parent link in visitation_links (visitation_links[nbr] = visiting)
					
					if nbr == grid_pos_goal:
						print("Goal found! Backtracing...")
						
						# TODO: Reconstruct the path from goal back to start
						# 1. Start with current_node = nbr
						# 2. Add current_node to the front of shortest_path
						# 3. Loop backward using visitation_links until reaching grid_pos_start
						# 4. Convert grid coordinates to world coordinates and return
						
						pass
					
					pass
		
	# Return
	return shortest_path
