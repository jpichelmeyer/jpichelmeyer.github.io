"""arc_meta.py -- the semester's specialists under one meta-level manager.
Put it in the folder with every lesson's arc_*.py file."""
import os, time
from arc_utils import load_task, dims, colors

# --- specialists ---
# Each specialist looks at a task and proposes solver functions (grid -> grid).
from arc_gt import solve as gt_solve, run as gt_run
from arc_rules import induce_rules, fire
from arc_logic import learn_truth_table, apply as tt_apply
from arc_priors import hypotheses as prior_hypotheses
from arc_complete import solve as complete, mask_color
from arc_config import configure, build
from arc_icl import learn as icl_learn, apply as icl_apply, BG
from arc_analogy import learn_mapping, transfer
from arc_ebl import learn as ebl_learn
from arc_classify import learn_stump, predict
from arc_diagnose import repair
from arc_script import instantiate, run_script
from arc_understand import common_frame, enact

def sp_search(t):
    prog, _ = gt_solve(t)
    return [lambda g, p=prog: gt_run(p, g)] if prog else []

def sp_rules(t):
    rs = induce_rules(t)
    return [lambda g, rs=rs: fire(rs, g)] if rs else []

def sp_logic(t):
    tt = learn_truth_table(t)
    return [lambda g, tt=tt: tt_apply(tt, g)] if tt and len(tt) == 4 else []

def sp_priors(t):
    return [h for _, h in prior_hypotheses(t)]

def sp_complete(t):
    m = mask_color(t)
    patch = any(dims(p['input']) != dims(p['output']) for p in t['train'])
    return [lambda g: complete(g, m, patch)[0]]

def sp_configure(t):
    cfg = configure(t)
    return [lambda g, cfg=cfg: build(cfg, g)] if cfg else []

def sp_concepts(t):
    out = []
    for bg in BG:
        cs = icl_learn(t, bg)
        if cs:
            out.append(lambda g, cs=cs, bg=bg: icl_apply(cs, g, bg))
    return out

def sp_analogy(t):
    m = learn_mapping(t)
    return [lambda g, m=m: transfer(m, g)] if m else []

def sp_ebl(t):
    r = ebl_learn(t)
    return [r] if r else []

def sp_classify(t):
    s = learn_stump(t)
    return [lambda g, s=s: predict(s, g)] if s else []

def sp_repair(t):
    prog, mapping, _ = repair(t)
    if prog is None:
        return []
    return [lambda g, p=prog, m=mapping or {}: [[m.get(v, v) for v in row] for row in gt_run(p, g)]]

def sp_script(t):
    slots = instantiate(t)
    return [lambda g, s=slots: run_script(g, *s)] if slots else []

def sp_events(t):
    f = common_frame(t)
    return [lambda g, f=f: enact(f, g)] if f else []

# --- triggers ---
def features(t):
    """What the meta level notices about a task before choosing a strategy."""
    ps = t['train']
    same = all(dims(p['input']) == dims(p['output']) for p in ps)
    hi, wi = dims(ps[0]['input'])
    ho, wo = dims(ps[0]['output'])
    return {'same_size': same, 'bigger': ho * wo > hi * wi, 'smaller': ho * wo < hi * wi,
            'multiple': ho % hi == 0 and wo % wi == 0 and (ho, wo) != (hi, wi),
            'halves': (ho, wo) in [(hi, wi // 2), (hi // 2, wi), (hi, (wi - 1) // 2), ((hi - 1) // 2, wi)],
            'mask': bool(set.intersection(*(colors(p['input']) - colors(p['output']) for p in ps))),
            'repeats': len({str(p['output']) for p in ps}) < len(ps)}

SPECIALISTS = {   # name: (function, trigger)
    'configuration': (sp_configure, lambda f: f['multiple']),
    'truth tables':  (sp_logic,     lambda f: f['halves']),
    'completion':    (sp_complete,  lambda f: f['mask']),
    'classification': (sp_classify, lambda f: f['repeats']),
    'local rules':   (sp_rules,     lambda f: f['same_size']),
    'priors':        (sp_priors,    lambda f: f['same_size']),
    'events':        (sp_events,    lambda f: f['same_size']),
    'analogy':       (sp_analogy,   lambda f: f['same_size']),
    'concepts':      (sp_concepts,  lambda f: f['same_size']),
    'scripts':       (sp_script,    lambda f: f['same_size']),
    'explanation':   (sp_ebl,       lambda f: True),
    'repair':        (sp_repair,    lambda f: True),
    'program search': (sp_search,   lambda f: True),
}

# --- meta ---
class MetaLevel:
    def __init__(self):
        self.record = {name: [1, 2] for name in SPECIALISTS}   # [successes+1, tries+2]

    def order(self, f):
        """Triggered specialists first; within each group, best track record first."""
        rate = lambda n: self.record[n][0] / self.record[n][1]
        return sorted(SPECIALISTS, key=lambda n: (not SPECIALISTS[n][1](f), -rate(n)))

    def verify(self, fn, t):
        try:
            return all(fn(p['input']) == p['output'] for p in t['train'])
        except Exception:
            return False

    def solve(self, t, budget=2.0):
        """Run specialists in order; keep every verified solver; stop with two
        distinct test answers or when the time budget is spent."""
        f, start, answers, credit = features(t), time.time(), [], []
        for name in self.order(f):
            if time.time() - start > budget:
                break
            fn_, trig = SPECIALISTS[name]
            try:
                candidates = fn_(t)
            except Exception:
                candidates = []
            self.record[name][1] += 1
            for fn in candidates:
                if self.verify(fn, t):
                    try:
                        guess = [fn(p['input']) for p in t['test']]
                    except Exception:
                        continue
                    if guess not in answers:
                        answers.append(guess)
                        credit.append(name)
                        self.record[name][0] += 1
            if len(answers) >= 2:
                break
        return answers[:2], credit[:2]

# --- run ---
if __name__ == '__main__':
    for split in ['training', 'evaluation']:
        meta, solved, by = MetaLevel(), 0, {}
        names = sorted(os.listdir('data/' + split))
        for name in names:
            t = load_task(f'data/{split}/{name}')
            answers, credit = meta.solve(t)
            truth = [p['output'] for p in t['test']]
            if truth in answers:
                solved += 1
                who = credit[answers.index(truth)]
                by[who] = by.get(who, 0) + 1
        print(f'{split}: solved {solved} of {len(names)}')
        for who, n in sorted(by.items(), key=lambda kv: -kv[1]):
            print(f'   {who:15} {n}')
