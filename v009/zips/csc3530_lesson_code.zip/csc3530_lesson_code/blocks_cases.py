# Learning by recording cases: remember examples, answer by nearest neighbour.
import math

# --- cases ---
# Each case: (width, height) of a block, and the colour it turned out to be.
CASES = [((1.0, 1.0), 'red'), ((1.0, 4.0), 'blue'), ((2.0, 4.5), 'blue'),
         ((4.0, 1.0), 'green'), ((5.0, 1.5), 'green'), ((1.5, 1.5), 'red'),
         ((3.0, 3.0), 'orange'), ((3.5, 2.5), 'orange')]

# --- recall ---
def distance(a, b):
    return math.dist(a, b)                     # straight-line distance

def nearest(query, cases, k=1):
    ranked = sorted(cases, key=lambda case: distance(query, case[0]))
    return ranked[:k]

def classify(query, cases, k=1):
    near = nearest(query, cases, k)
    votes = {}
    for _, label in near:
        votes[label] = votes.get(label, 0) + 1
    return max(votes, key=votes.get), near

# --- use ---
for q in [(1.2, 1.1), (4.5, 1.2), (2.6, 2.9), (2.5, 4.0)]:
    label, near = classify(q, CASES)
    print(f'block {q}: nearest case {near[0][0]} -> {label}')

# --- k ---
print('a borderline block with k = 1 and k = 3:')
for k in (1, 3):
    label, near = classify((2.2, 2.2), CASES, k)
    print(f'  k={k}: {label}  from {[c[1] for c in near]}')

# --- record ---
CASES.append(((2.2, 2.2), 'red'))              # a teacher says it was red
print('after recording the correction:', classify((2.3, 2.1), CASES)[0])
