# --- load ---
from arc_utils import load_task, show, dims, find_objects, COLOR_NAMES

task = load_task('data/training/0ca9ddb6.json')
print('training pairs:', len(task['train']))
print('test inputs:   ', len(task['test']))

first = task['train'][0]
print('input size: ', dims(first['input']))
print('output size:', dims(first['output']))
show(first['input'], 'train 0 input')
show(first['output'], 'train 0 output')
# --- objects ---
for obj in find_objects(first['input']):
    print(COLOR_NAMES[obj['color']], 'object of size', obj['size'],
          'at row', obj['top'], 'col', obj['left'])
