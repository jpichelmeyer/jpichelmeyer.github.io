import os, itertools
from arc_utils import (load_task, dims, find_objects, crop_object, flip_h, flip_v,
                       transpose, rotate180, hconcat, vconcat, scale)

# --- operators ---
def largest(g):
    return crop_object(g, max(find_objects(g), key=lambda o: o['size']))

def desc(g):
    """The abstract state a planner reasons about: grid size and the size
    of the largest object. Cheap to compute, ignores colours entirely."""
    objs = find_objects(g)
    big = max(objs, key=lambda o: o['size']) if objs else None
    return {'h': len(g), 'w': len(g[0]),
            'oh': big['height'] if big else 0, 'ow': big['width'] if big else 0}

# name: (precondition on desc, effect on desc, concrete function)
SIZE_OPS = {
    'crop_largest': (lambda d: d['oh'] > 0, lambda d: dict(d, h=d['oh'], w=d['ow']), largest),
    'double_w':     (lambda d: True, lambda d: dict(d, w=2 * d['w']), lambda g: hconcat(g, g)),
    'double_h':     (lambda d: True, lambda d: dict(d, h=2 * d['h']), lambda g: vconcat(g, g)),
    'mirror_w':     (lambda d: True, lambda d: dict(d, w=2 * d['w']), lambda g: hconcat(g, flip_h(g))),
    'mirror_h':     (lambda d: True, lambda d: dict(d, h=2 * d['h']), lambda g: vconcat(g, flip_v(g))),
    'scale2':       (lambda d: True, lambda d: dict(d, h=2 * d['h'], w=2 * d['w']), lambda g: scale(g, 2)),
    'scale3':       (lambda d: True, lambda d: dict(d, h=3 * d['h'], w=3 * d['w']), lambda g: scale(g, 3)),
    'transpose':    (lambda d: True, lambda d: dict(d, h=d['w'], w=d['h']), transpose),
}
NEUTRAL = {'none': lambda g: g, 'flip_h': flip_h, 'flip_v': flip_v, 'rot180': rotate180}

# --- abstract ---
def abstract_plans(task, max_len=2):
    """Plan in the abstract space: every sequence of size-changing operators
    whose predicted effect turns each train input's size into its output's."""
    starts = [desc(p['input']) for p in task['train']]
    goals = [(len(p['output']), len(p['output'][0])) for p in task['train']]
    for n in range(0, max_len + 1):
        for seq in itertools.product(SIZE_OPS, repeat=n):
            ok = True
            for d, goal in zip(starts, goals):
                for name in seq:
                    pre, eff, _ = SIZE_OPS[name]
                    if not pre(d):
                        ok = False
                        break
                    d = eff(d)
                if not ok or (d['h'], d['w']) != goal:
                    ok = False
                    break
            if ok:
                yield seq

# --- refine ---
def refine(seq, task):
    """Turn an abstract plan into a concrete program by optionally inserting
    one size-neutral operator, and keep the first that fits every pair."""
    for pos in range(len(seq) + 1):
        for nname, nf in NEUTRAL.items():
            prog = list(seq[:pos]) + [nname] + list(seq[pos:])
            def run(g, prog=prog):
                for step in prog:
                    g = NEUTRAL[step](g) if step in NEUTRAL else SIZE_OPS[step][2](g)
                return g
            try:
                if all(run(p['input']) == p['output'] for p in task['train']):
                    return [s for s in prog if s != 'none'], run
            except Exception:
                pass
    return None, None

# --- sweep ---
if __name__ == '__main__':
    solved, checked = [], 0
    for name in sorted(os.listdir('data/training')):
        task = load_task('data/training/' + name)
        for seq in abstract_plans(task):
            checked += 1
            prog, run = refine(seq, task)
            if prog is not None:
                if all(run(t['input']) == t['output'] for t in task['test']):
                    solved.append((name[:-5], ' then '.join(prog) or 'identity'))
                break
    print(f'abstract plans refined: {checked}; tasks solved: {len(solved)}')
    for tid, prog in solved:
        print(f'  {tid}: {prog}')
