# A tiny SAM agent that continues number sequences.
# Environment: a puzzle string like "2, 4, 6, 8, ?"
# Perceptor -> list of ints; Memory -> rules it knows + what happened;
# Decider -> picks a rule; Actuator -> answers; Monitor -> checks the Decider.

# --- perceptor ---
class Perceptor:
    def perceive(self, puzzle):
        """Turn raw text into a symbolic percept: a list of ints."""
        parts = [p.strip() for p in puzzle.split(',')]
        return [int(p) for p in parts if p != '?']

# --- memory ---
class Memory:
    def __init__(self):
        self.working = {}            # the current situation
        self.procedural = {          # long-term: rules it knows how to apply
            'add a constant': self.add_rule,
            'multiply by a constant': self.mul_rule,
        }
        self.episodic = []           # long-term: a log of past episodes

    @staticmethod
    def add_rule(seq):
        d = seq[1] - seq[0]
        return lambda i: seq[0] + d * i

    @staticmethod
    def mul_rule(seq):
        if seq[0] == 0:
            return None
        r = seq[1] // seq[0]
        return lambda i: seq[0] * r ** i

# --- decider ---
class Decider:
    def decide(self, memory, monitor):
        seq = memory.working['seq']
        for name, make in memory.procedural.items():
            rule = make(seq)
            if rule and monitor.explains(rule, seq):     # metacognitive check
                return name, rule(len(seq))
        return None, None

# --- actuator ---
class Actuator:
    def act(self, name, answer):
        if name is None:
            print('  answer: I do not know this kind of sequence')
        else:
            print(f'  answer: {answer}   (rule: {name})')

# --- monitor ---
class Monitor:
    """Watches the Decider instead of the world. Does the rule it picked
    actually reproduce every number we were shown?"""
    def explains(self, rule, seq):
        return all(rule(i) == x for i, x in enumerate(seq))

    def reflect(self, memory, name):
        memory.episodic.append((memory.working['seq'], name))
        if name is None:
            print('  monitor: no rule fit; this episode is marked for learning')

# --- agent ---
class SequenceAgent:
    def __init__(self):
        self.perceptor, self.memory = Perceptor(), Memory()
        self.decider, self.actuator, self.monitor = Decider(), Actuator(), Monitor()

    def step(self, puzzle):
        print(puzzle)
        self.memory.working['seq'] = self.perceptor.perceive(puzzle)
        name, answer = self.decider.decide(self.memory, self.monitor)
        self.actuator.act(name, answer)
        self.monitor.reflect(self.memory, name)

agent = SequenceAgent()
for puzzle in ['2, 4, 6, 8, ?', '3, 6, 12, 24, ?', '1, 4, 9, 16, ?']:
    agent.step(puzzle)

# --- learn ---
# Learning = writing a new rule into long-term (procedural) memory.
def square_rule(seq):
    return lambda i: (i + 1) ** 2

agent.memory.procedural['squares'] = square_rule
print('-- after learning --')
agent.step('1, 4, 9, 16, ?')
print('episodes remembered:', len(agent.memory.episodic))
