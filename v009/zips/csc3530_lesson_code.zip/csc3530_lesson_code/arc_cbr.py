import os
from arc_utils import load_task, dims, colors
from arc_gt import PRIMS, run           # primitives from the generate-and-test lesson

# --- library ---
# Cases recorded from tasks solved earlier: (training task, program that solved it)
LIBRARY = [('a416b8f3', ('double_w',)), ('3af2c5a8', ('mirror_w', 'mirror_h')),
           ('67a3c6ac', ('flip_h',)), ('74dd1130', ('transpose',)), ('c59eb873', ('scale2',)),
           ('9172f3a0', ('scale3',)), ('1cf80156', ('crop_all',)), ('be94b721', ('largest',)),
           ('1e0a9b12', ('gravity',)), ('28bf18c6', ('crop_all', 'double_w')),
           ('7468f01a', ('flip_h', 'crop_all')), ('6d0aefbc', ('mirror_w',)),
           ('496994bd', ('top_half', 'mirror_h')), ('3c9b0459', ('rot180',))]

# --- index ---
def features(task):
    """How a task is indexed: the things a person notices first."""
    p = task['train'][0]
    hi, wi = dims(p['input'])
    ho, wo = dims(p['output'])
    return {'same_size': (hi, wi) == (ho, wo),
            'ratio': (round(ho / hi, 2), round(wo / wi, 2)),
            'shrinks': ho * wo < hi * wi,
            'new_colors': bool(colors(p['output']) - colors(p['input'])),
            'square_in': hi == wi}

def similarity(f1, f2):
    return sum(f1[k] == f2[k] for k in f1)

# --- adapt ---
RELATED = {'flip_h': ['flip_v', 'transpose'], 'flip_v': ['flip_h'], 'rot90': ['rot270', 'rot180'],
           'rot270': ['rot90'], 'rot180': ['rot90', 'rot270', 'flip_h', 'flip_v'],
           'double_w': ['double_h', 'mirror_w'], 'double_h': ['double_w', 'mirror_h'],
           'mirror_w': ['mirror_h', 'double_w'], 'mirror_h': ['mirror_w', 'double_h'],
           'scale2': ['scale3'], 'scale3': ['scale2'], 'largest': ['smallest', 'crop_all'],
           'smallest': ['largest'], 'crop_all': ['largest'], 'top_half': ['left_half'],
           'left_half': ['top_half'], 'transpose': ['rot90', 'rot270'], 'gravity': []}

def adaptations(prog):
    """The old program first, then every one-step substitution."""
    yield prog
    for i, step in enumerate(prog):
        for alt in RELATED.get(step, []):
            yield prog[:i] + (alt,) + prog[i + 1:]

def fits(prog, task):
    try:
        return all(run(prog, p['input']) == p['output'] for p in task['train'])
    except Exception:
        return False

# --- cbr ---
def cbr(task, k=3):
    """Retrieve the k most similar cases, adapt, evaluate on the train pairs."""
    f = features(task)
    ranked = sorted(LIBRARY, key=lambda c: -similarity(f, features(CASE_TASKS[c[0]])))
    tried = 0
    for case_id, prog in ranked[:k]:
        for candidate in adaptations(prog):
            tried += 1
            if fits(candidate, task):
                return case_id, candidate, tried
    return None, None, tried

CASE_TASKS = {cid: load_task(f'data/training/{cid}.json') for cid, _ in LIBRARY}

# --- sweep ---
if __name__ == '__main__':
    for split in ['training', 'evaluation']:
        solved, tried_total = [], 0
        for name in sorted(os.listdir('data/' + split)):
            tid = name[:-5]
            if tid in CASE_TASKS:
                continue                                  # don't test on the library
            task = load_task(f'data/{split}/{name}')
            case_id, prog, tried = cbr(task)
            tried_total += tried
            if prog and all(run(prog, t['input']) == t['output'] for t in task['test']):
                solved.append((tid, case_id, prog))
                LIBRARY.append((tid, prog))               # store the new case
                CASE_TASKS[tid] = task
        print(f'{split}: solved {len(solved)}, trying {tried_total} programs in all')
        for tid, case_id, prog in solved:
            print(f'  {tid}: reminded of {case_id} -> {" then ".join(prog)}')
