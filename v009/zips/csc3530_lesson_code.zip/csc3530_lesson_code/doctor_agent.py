# Abductive diagnosis: find the smallest set of hypotheses that explains
# every observation (after Goel & Joyner's KBAI diagnosis example).
from itertools import combinations

# --- knowledge ---
# Each disorder raises (+) or lowers (-) some lab values.
DISORDERS = {
    'Alphaitis': {'A': '+', 'C': '-', 'F': '+'},
    'Betatosis': {'B': '+', 'C': '+', 'D': '-'},
    'Gammonia':  {'A': '-', 'E': '+'},
    'Deltacol':  {'B': '-', 'F': '+'},
    'Epsilitis': {'C': '+', 'D': '-', 'E': '+'},
    'Zetad':     {'A': '+', 'B': '+', 'D': '-', 'F': '+'},
}
PRIOR = {'Alphaitis': 0.10, 'Betatosis': 0.05, 'Gammonia': 0.02,
         'Deltacol': 0.08, 'Epsilitis': 0.03, 'Zetad': 0.01}

# --- predict ---
def predict(hypotheses):
    """Combined effect of several disorders: opposite effects cancel."""
    total = {}
    for h in hypotheses:
        for test, sign in DISORDERS[h].items():
            total[test] = total.get(test, 0) + (1 if sign == '+' else -1)
    return {t: ('+' if v > 0 else '-') for t, v in total.items() if v != 0}

# --- explain ---
def diagnose(observed, max_size=3):
    """Coverage: the prediction must match the observations exactly.
    Parsimony: try one disorder, then pairs, then triples, and stop at the
    smallest size that works. Plausibility: rank ties by prior probability."""
    for size in range(1, max_size + 1):
        found = [set(c) for c in combinations(DISORDERS, size) if predict(c) == observed]
        if found:
            return sorted(found, key=lambda c: -min(PRIOR[h] for h in c))
    return []

# --- cases ---
for observed in [{'A': '+', 'C': '-', 'F': '+'},
                 {'A': '+', 'B': '+', 'D': '-', 'F': '+'},
                 {'B': '+', 'D': '-', 'F': '+', 'A': '+', 'C': '+'}]:
    print('observed:', observed)
    for expl in diagnose(observed):
        print('   explained by', sorted(expl), ' prior', min(PRIOR[h] for h in expl))

# --- interactions ---
obs = {'A': '+', 'B': '+', 'D': '-', 'F': '+'}
pairs = [sorted(c) for c in combinations(DISORDERS, 2) if predict(c) == obs]
print('pairs that also explain case 2:', pairs)
print('  Alphaitis lowers C and Betatosis raises it: the effects cancel.')
