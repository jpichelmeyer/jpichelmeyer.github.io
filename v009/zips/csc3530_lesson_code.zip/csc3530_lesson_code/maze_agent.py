# Pathfinding as generate and test: breadth-first search on a grid maze.
from collections import deque

MAZE = ['S.#.....',
        '.##.###.',
        '....#...',
        '.##.#.#.',
        '.#..#.#G']

def find(ch):
    for r, row in enumerate(MAZE):
        if ch in row:
            return r, row.index(ch)

def neighbours(cell):                          # the generator
    r, c = cell
    for dr, dc in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(MAZE) and 0 <= nc < len(MAZE[0]) and MAZE[nr][nc] != '#':
            yield nr, nc

def bfs(start, goal):
    frontier, came_from = deque([start]), {start: None}
    while frontier:
        cell = frontier.popleft()
        if cell == goal:                       # the tester
            path = []
            while cell:
                path.append(cell)
                cell = came_from[cell]
            return path[::-1], len(came_from)
        for nxt in neighbours(cell):
            if nxt not in came_from:
                came_from[nxt] = cell
                frontier.append(nxt)
    return None, len(came_from)

path, explored = bfs(find('S'), find('G'))
print(f'path of {len(path) - 1} steps, {explored} cells explored')
for r, row in enumerate(MAZE):
    print(''.join('*' if (r, c) in path and ch == '.' else ch for c, ch in enumerate(row)))
