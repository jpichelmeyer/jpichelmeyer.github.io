import os
from arc_utils import load_task, dims

# --- patch ---
def patch(grid, r, c):
    """The 3x3 neighbourhood around a cell, as a tuple (-1 = off the grid)."""
    h, w = dims(grid)
    return tuple(grid[y][x] if 0 <= y < h and 0 <= x < w else -1
                 for y in (r - 1, r, r + 1) for x in (c - 1, c, c + 1))

# --- record ---
def record(task):
    """Case library: every 3x3 input patch seen in training, with the output
    colour of its centre cell. Fails if outputs differ in size from inputs."""
    library = {}
    for pair in task['train']:
        inp, out = pair['input'], pair['output']
        if dims(inp) != dims(out):
            return None
        for r in range(len(inp)):
            for c in range(len(inp[0])):
                library.setdefault(patch(inp, r, c), []).append(out[r][c])
    return library

# --- recall ---
def recall(library, grid, max_diff):
    """Answer each cell from memory. Use the exact patch if it was recorded;
    otherwise the most similar recorded patch, but only if it differs in at
    most max_diff of its 9 cells; otherwise just keep the cell's colour."""
    out = []
    for r in range(len(grid)):
        row = []
        for c in range(len(grid[0])):
            key = patch(grid, r, c)
            best = key if key in library else min(
                library, key=lambda k: sum(a != b for a, b in zip(k, key)))
            diff = sum(a != b for a, b in zip(best, key))
            if diff <= max_diff:
                votes = library[best]
                row.append(max(set(votes), key=votes.count))
            else:
                row.append(grid[r][c])
        out.append(row)
    return out

# --- sweep ---
if __name__ == '__main__':
    for max_diff, label in [(0, 'exact match only'), (9, 'always use nearest case'),
                            (1, 'nearest case if it differs in only 1 cell')]:
        solved = []
        for name in sorted(os.listdir('data/training')):
            task = load_task('data/training/' + name)
            lib = record(task)
            if lib and all(recall(lib, t['input'], max_diff) == t['output'] for t in task['test']):
                solved.append(name[:-5])
        print(f'{label:42} -> {len(solved)} tasks: {" ".join(solved)}')
