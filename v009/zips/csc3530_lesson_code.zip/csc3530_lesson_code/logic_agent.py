# Forward chaining, backward chaining, and resolution.
# --- kb ---
# Horn clauses: (set of premises, conclusion)
RULES = [
    ({'has-feathers'}, 'bird'),
    ({'bird', 'can-not-fly', 'swims'}, 'penguin'),
    ({'bird', 'flies', 'sings'}, 'songbird'),
    ({'songbird', 'yellow'}, 'canary'),
]
FACTS = {'has-feathers', 'flies', 'sings', 'yellow'}

# --- forward ---
def forward_chain(facts, rules):
    """Data-driven: keep firing any rule whose premises are all known."""
    known, changed = set(facts), True
    while changed:
        changed = False
        for premises, conclusion in rules:
            if premises <= known and conclusion not in known:
                print(f'  {" & ".join(sorted(premises))}  =>  {conclusion}')
                known.add(conclusion)
                changed = True
    return known

print('forward chaining:')
forward_chain(FACTS, RULES)

# --- backward ---
def backward_chain(goal, facts, rules, depth=0):
    """Goal-driven: to prove a goal, find a rule that concludes it and
    prove each premise. Prints the proof tree as it goes."""
    pad = '    ' * depth
    if goal in facts:
        print(f'{pad}{goal}: given')
        return True
    for premises, conclusion in rules:
        if conclusion == goal:
            print(f'{pad}{goal}: try rule needing {sorted(premises)}')
            if all(backward_chain(p, facts, rules, depth + 1) for p in sorted(premises)):
                return True
    print(f'{pad}{goal}: cannot prove')
    return False

print('backward chaining: is it a canary?')
backward_chain('canary', FACTS, RULES)

# --- resolution ---
def resolve(c1, c2):
    """All resolvents of two clauses (frozensets of literals, '-' = not)."""
    out = []
    for lit in c1:
        neg = lit[1:] if lit.startswith('-') else '-' + lit
        if neg in c2:
            out.append((c1 - {lit}) | (c2 - {neg}))
    return out

def refute(clauses, query):
    """Proof by contradiction: add NOT query; if the empty clause can be
    derived, the query follows from the clauses."""
    neg = query[1:] if query.startswith('-') else '-' + query
    clauses = {frozenset(c) for c in clauses} | {frozenset([neg])}
    while True:
        new = set()
        for a in clauses:
            for b in clauses:
                if a < b or a == b:
                    continue
                for r in resolve(a, b):
                    if not r:
                        print(f'  {set(a)} + {set(b)} -> empty clause: contradiction')
                        return True
                    new.add(frozenset(r))
        if new <= clauses:
            return False
        clauses |= new

# "Penguins are birds", "birds fly unless they are penguins", "Pingu is a penguin"
# in clause form:  -penguin | bird ;  -bird | penguin | flies ; penguin
print('resolution: does Pingu fly?', refute([{'-penguin', 'bird'}, {'-bird', 'penguin', 'flies'}, {'penguin'}], 'flies'))
print('resolution: is Pingu a bird?')
print('  proved:', refute([{'-penguin', 'bird'}, {'-bird', 'penguin', 'flies'}, {'penguin'}], 'bird'))
