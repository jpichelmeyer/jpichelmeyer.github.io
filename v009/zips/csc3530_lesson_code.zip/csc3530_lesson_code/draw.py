# Optional: draw a grid in ARC colours (needs matplotlib).
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from arc_utils import load_task

ARC_CMAP = ListedColormap(['#000000', '#0074D9', '#FF4136', '#2ECC40', '#FFDC00',
                           '#AAAAAA', '#F012BE', '#FF851B', '#7FDBFF', '#870C25'])

def draw(grid, ax, title=''):
    ax.imshow(grid, cmap=ARC_CMAP, vmin=0, vmax=9)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_title(title)

task = load_task('data/training/0ca9ddb6.json')
fig, axes = plt.subplots(2, len(task['train']), figsize=(3 * len(task['train']), 6))
for i, pair in enumerate(task['train']):
    draw(pair['input'], axes[0][i], f'train {i} in')
    draw(pair['output'], axes[1][i], f'train {i} out')
plt.tight_layout()
plt.show()
