from arc_utils import load_task

# --- prompt ---
def to_text(grid):
    return '\n'.join(' '.join(str(v) for v in row) for row in grid)

def build_prompt(task):
    """Serialize an ARC task as text, the way a language model must see it."""
    parts = ['Each example maps an input grid to an output grid. Find the rule.',
             'Answer with a Python function  solve(grid) -> grid  (grids are lists of lists of ints).', '']
    for i, p in enumerate(task['train'], 1):
        parts += [f'Example {i} input:', to_text(p['input']), f'Example {i} output:', to_text(p['output']), '']
    parts += ['Test input:', to_text(task['test'][0]['input'])]
    return '\n'.join(parts)

task = load_task('data/training/b1948b0a.json')
prompt = build_prompt(task)
print(prompt[:320] + '\n...')

# --- verify ---
# Pretend a language model proposed these three programs as text.
CANDIDATES = [
    "def solve(grid):\n    return [[2 if v == 6 else v for v in row] for row in grid]",
    "def solve(grid):\n    return [[2 for v in row] for row in grid]",
    "def solve(grid):\n    return grid.transpose()",
]

SAFE_BUILTINS = {'range': range, 'len': len, 'min': min, 'max': max, 'sum': sum,
                 'list': list, 'enumerate': enumerate, 'zip': zip, 'sorted': sorted}

def verify(source, task):
    """The symbolic half: run the proposed program on every train pair and
    accept it only if all of them come out exactly right. (Restricting the
    builtins limits accidents; it is NOT a security sandbox.)"""
    env = {'__builtins__': SAFE_BUILTINS}
    try:
        exec(source, env)
        solve = env['solve']
        return all(solve(p['input']) == p['output'] for p in task['train']), solve
    except Exception as e:
        return False, f'crashed: {type(e).__name__}'

for k, src in enumerate(CANDIDATES, 1):
    ok, result = verify(src, task)
    status = 'accepted' if ok else ('rejected' if callable(result) else result)
    print(f'candidate {k}: {status}')
    if ok:
        print('  test correct:', result(task['test'][0]['input']) == task['test'][0]['output'])
