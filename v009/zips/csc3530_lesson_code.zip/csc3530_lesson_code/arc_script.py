import os
from arc_utils import load_task, find_objects, dims

# --- script ---
# The "object task" script: a stereotyped sequence with open slots.
#   1. find the objects            (fixed)
#   2. SELECT some of them         (slot)
#   3. apply an ACTION to each     (slot)
#   4. draw the result             (fixed)
SELECT = {
    'all':      lambda objs, o: True,
    'largest':  lambda objs, o: o['size'] == max(x['size'] for x in objs),
    'smallest': lambda objs, o: o['size'] == min(x['size'] for x in objs),
    'not largest': lambda objs, o: o['size'] != max(x['size'] for x in objs),
    'single cells': lambda objs, o: o['size'] == 1,
    'touching the edge': lambda objs, o: o['edge'],
    'not touching the edge': lambda objs, o: not o['edge'],
}
ACTIONS = ['recolor', 'delete', 'keep only these']

def run_script(grid, select, action, color=None, of_color=None):
    h, w = dims(grid)
    objs = find_objects(grid, bg=0, diagonal=True)
    for o in objs:
        o['edge'] = o['top'] == 0 or o['left'] == 0 or o['bottom'] == h - 1 or o['right'] == w - 1
    chosen = [o for o in objs if SELECT[select](objs, o)
              and (of_color is None or o['color'] == of_color)]
    out = [row[:] for row in grid]
    if action == 'keep only these':
        out = [[0] * w for _ in range(h)]
        for o in chosen:
            for r, c in o['cells']:
                out[r][c] = grid[r][c]
    for o in chosen:
        for r, c in o['cells']:
            if action == 'recolor':
                out[r][c] = color
            elif action == 'delete':
                out[r][c] = 0
    return out

# --- instantiate ---
def instantiate(task):
    """Fill the script's slots so that every train pair is reproduced.
    The recolour constant is read off the first pair."""
    p0 = task['train'][0]
    if dims(p0['input']) != dims(p0['output']):
        return None
    out_colors = sorted({v for row in p0['output'] for v in row} - {0})
    in_colors = [None] + sorted({v for row in p0['input'] for v in row} - {0})
    for of_color in in_colors:                 # optional extra slot: only objects of one colour
        for select in SELECT:
            for action in ACTIONS:
                for color in (out_colors if action == 'recolor' else [None]):
                    if all(run_script(p['input'], select, action, color, of_color) == p['output']
                           for p in task['train']):
                        return select, action, color, of_color
    return None

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        slots = instantiate(t)
        if slots and all(run_script(p['input'], *slots) == p['output'] for p in t['test']):
            sel, act, col, of = slots
            who = sel + (f' of colour {of}' if of is not None else '')
            solved.append(f'{name[:-5]}: select {who}; {act}' + (f' {col}' if col is not None else ''))
    print(len(solved), 'tasks')
    for s in solved:
        print(' ', s)
