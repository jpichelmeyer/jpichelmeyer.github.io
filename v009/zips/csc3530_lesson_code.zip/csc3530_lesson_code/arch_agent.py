# Incremental concept learning (after Winston's arch learner).
# --- background ---
ISA = {'brick': 'block', 'wedge': 'block', 'cylinder': 'block', 'block': 'thing'}

def climb(a, b):
    """Lowest common ancestor of two classes in the is-a tree."""
    chain = [a]
    while chain[-1] in ISA:
        chain.append(ISA[chain[-1]])
    while b not in chain:
        b = ISA[b]
    return b

def is_a(x, y):
    while x != y and x in ISA:
        x = ISA[x]
    return x == y

# --- examples ---
# An example: parts with types and colours, plus relations between parts.
def scene(top, top_color, left_touches_right, supported):
    rel = {('left', 'supports', 'top'), ('right', 'supports', 'top')} if supported else set()
    if left_touches_right:
        rel.add(('left', 'touches', 'right'))
    return {'types': {'left': 'brick', 'right': 'brick', 'top': top},
            'colors': {'top': top_color}, 'relations': rel}

# --- learner ---
class Concept:
    def __init__(self, first):
        self.types = dict(first['types'])
        self.colors = {p: {c} for p, c in first['colors'].items()}
        self.relations = set(first['relations'])   # may be dropped later
        self.must, self.must_not = set(), set()

    def covers(self, ex):
        return (all(is_a(ex['types'][p], t) for p, t in self.types.items())
                and all(ex['colors'][p] in cs for p, cs in self.colors.items())
                and self.must <= ex['relations'] and not (self.must_not & ex['relations']))

    def positive(self, ex):
        for p, t in self.types.items():               # climb-tree
            if not is_a(ex['types'][p], t):
                self.types[p] = climb(t, ex['types'][p])
                print(f'    climb-tree: {p} can be any {self.types[p]}')
        for p, cs in self.colors.items():             # enlarge-set
            if ex['colors'][p] not in cs:
                cs.add(ex['colors'][p])
                print(f'    enlarge-set: {p} colour in {sorted(cs)}')
        for r in self.relations - ex['relations'] - self.must:   # drop-link
            self.relations.discard(r)
            print(f'    drop-link: {r} is not needed')

    def negative(self, ex):
        for r in self.relations - ex['relations']:   # require-link
            self.must.add(r)
            print(f'    require-link: must have {r}')
        for r in ex['relations'] - self.relations:   # forbid-link
            self.must_not.add(r)
            print(f'    forbid-link: must not have {r}')

# --- teach ---
lessons = [
    ('+', scene('brick', 'red', False, True), 'an arch'),
    ('-', scene('brick', 'red', True, True), 'posts touch: not an arch'),
    ('-', scene('brick', 'red', False, False), 'top lies beside the posts: not an arch'),
    ('+', scene('wedge', 'red', False, True), 'a wedge on top is still an arch'),
    ('+', scene('brick', 'blue', False, True), 'a blue top is still an arch'),
]
concept = None
for sign, ex, note in lessons:
    print(f'{sign} {note}')
    if concept is None:
        concept = Concept(ex)
    elif sign == '+':
        concept.positive(ex)
    else:
        concept.negative(ex)

print('test: cylinder top, green, posts apart ->',
      concept.covers(scene('cylinder', 'green', False, True)))
print('test: cylinder top, blue, posts apart ->',
      concept.covers(scene('cylinder', 'blue', False, True)))
