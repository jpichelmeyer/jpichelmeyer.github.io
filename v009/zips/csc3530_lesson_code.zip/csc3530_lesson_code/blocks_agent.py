# Means-ends analysis and problem reduction in the blocks world.
from itertools import permutations

# --- world ---
# A state maps each block to what it sits on ('table' or another block).
def clear(state, b):
    return all(under != b for under in state.values())

def moves(state):
    """Operator Move(block, dest): legal if the block is clear and the
    destination is clear (the table always is)."""
    for b in state:
        if not clear(state, b):
            continue
        for dest in ['table'] + [d for d in state if d != b]:
            if dest != state[b] and (dest == 'table' or clear(state, dest)):
                new = dict(state)
                new[b] = dest
                yield (b, dest), new

# --- mea ---
def holds(state, cond):
    kind, x, *y = cond
    return state[x] == y[0] if kind == 'on' else clear(state, x)

def difference(state, goals):
    """How many goal conditions are not yet true."""
    return sum(not holds(state, g) for g in goals)

def mea(state, goals, protect=(), limit=8, verbose=True):
    """Repeatedly apply the operator that most reduces the difference.
    Never break a protected condition, never revisit a state."""
    plan, seen = [], {tuple(sorted(state.items()))}
    while difference(state, goals) > 0:
        options = [(difference(new, goals), op, new) for op, new in moves(state)
                   if tuple(sorted(new.items())) not in seen
                   and all(holds(new, p) for p in protect)]
        if not options or len(plan) >= limit:
            if verbose:
                print('    stuck: every move repeats a state or breaks a protected goal')
            return None, state
        d, op, state = min(options, key=lambda o: o[0])
        seen.add(tuple(sorted(state.items())))
        plan.append(op)
        if verbose:
            print(f'    move {op[0]} onto {op[1]:5}   difference now {d}')
    return plan, state

# --- easy ---
print('Problem 1: B sits on A; goal: A on C')
mea({'A': 'table', 'B': 'A', 'C': 'table'}, [('on', 'A', 'C')])

# --- sussman ---
START = {'A': 'table', 'B': 'table', 'C': 'A'}
GOAL = [('on', 'A', 'B'), ('on', 'B', 'C')]
print('Problem 2 (the Sussman anomaly): C on A; goal: A on B and B on C')
mea(START, GOAL)

# --- reduce ---
def reduce(state, goals):
    """Problem reduction: break the goal into subgoals (every block involved
    must be clear at some point, then each 'on' must hold), and search for
    an order of subgoals that MEA can achieve one at a time. Each 'on'
    is protected once achieved so later steps cannot undo it."""
    blocks = sorted({b for _, x, y in goals for b in (x, y) if b != 'table'})
    subgoals = [('clear', b) for b in blocks] + list(goals)
    for tried, order in enumerate(permutations(subgoals), 1):
        s, plan, protect = dict(state), [], []
        for g in order:
            steps, s = mea(s, [g], protect=protect, verbose=False)
            if steps is None:
                break
            plan += steps
            if g[0] == 'on':
                protect.append(g)
        if difference(s, goals) == 0:
            return order, plan, tried
    return None, None, tried

print('Problem 2 with problem reduction:')
order, plan, tried = reduce(START, GOAL)
print('    orders tried:', tried)
print('    subgoal order:', order)
print('    plan:', plan)
