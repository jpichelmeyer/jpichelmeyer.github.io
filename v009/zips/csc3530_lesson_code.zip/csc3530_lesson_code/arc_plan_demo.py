from arc_utils import load_task
from arc_plan import abstract_plans, refine

task = load_task('data/training/3af2c5a8.json')
skeletons = list(abstract_plans(task))
print(len(skeletons), 'abstract plans reach the right output size:')
for seq in skeletons:
    prog, _ = refine(seq, task)
    print(f'  {" then ".join(seq):24} ->', 'fits: ' + ' then '.join(prog) if prog else 'no refinement fits')
