import os
from collections import Counter
from arc_utils import load_task, find_objects, dims

# --- pipeline ---
# The agent's answer depends on PERCEPTUAL assumptions (how objects are
# found) and on a DECISION (which objects to change, and how).
DEFAULT = {'connect_diagonally': False, 'background': 'black', 'one_colour_objects': True}

def perceive(grid, assumptions):
    bg = 0 if assumptions['background'] == 'black' else \
        Counter(v for row in grid for v in row).most_common(1)[0][0]
    return find_objects(grid, bg=bg, diagonal=assumptions['connect_diagonally'],
                        by_color=assumptions['one_colour_objects']), bg

SELECT = {'smallest': lambda objs, o: o['size'] == min(x['size'] for x in objs),
          'largest': lambda objs, o: o['size'] == max(x['size'] for x in objs),
          'not largest': lambda objs, o: o['size'] != max(x['size'] for x in objs),
          'single cells': lambda objs, o: o['size'] == 1,
          'all': lambda objs, o: True}

def act(grid, assumptions, decision):
    objs, bg = perceive(grid, assumptions)
    if not objs:
        return None
    select, new_color = decision
    out = [row[:] for row in grid]
    for o in objs:
        if SELECT[select](objs, o):
            for r, c in o['cells']:
                out[r][c] = bg if new_color == 'erase' else new_color
    return out

def fit_decision(pair, assumptions):
    """Choose the decision that reproduces one pair, under given assumptions."""
    colors = sorted({v for row in pair['output'] for v in row}) + ['erase']
    for select in SELECT:
        for k in colors:
            if act(pair['input'], assumptions, (select, k)) == pair['output']:
                return (select, k)
    return None

# --- learn ---
def learn(task, verbose=False):
    """Fit on pair 1 under the default assumptions. Each later pair that
    comes out WRONG is a mistake: assign blame by changing one assumption
    at a time; keep the change that fixes the mistake without breaking
    the pairs already explained."""
    assumptions = dict(DEFAULT)
    seen = [task['train'][0]]
    decision = fit_decision(seen[0], assumptions)
    for i, pair in enumerate(task['train'][1:], start=2):
        if decision and act(pair['input'], assumptions, decision) == pair['output']:
            seen.append(pair)
            continue
        if verbose:
            print(f'  mistake on pair {i}')
        fixed = False
        for name, alt in [('connect_diagonally', not assumptions['connect_diagonally']),
                          ('background', 'majority' if assumptions['background'] == 'black' else 'black'),
                          ('one_colour_objects', not assumptions['one_colour_objects'])]:
            trial = dict(assumptions, **{name: alt})
            d = fit_decision(seen[0], trial)
            if d and all(act(p['input'], trial, d) == p['output'] for p in seen + [pair]):
                if verbose:
                    print(f'    blame: the assumption {name}={assumptions[name]}; changed to {alt}')
                assumptions, decision, fixed = trial, d, True
                break
        if not fixed:
            return None, None
        seen.append(pair)
    return assumptions, decision

# --- demo ---
if __name__ == '__main__':
    for tid in ['42a50994']:
        task = load_task(f'data/training/{tid}.json')
        print(tid)
        a, d = learn(task, verbose=True)
        print('   learned:', a, d)

# --- sweep ---
if __name__ == '__main__':
    solved, blamed = [], Counter()
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        a, d = learn(t)
        if a and d and all(act(p['input'], a, d) == p['output'] for p in t['test']):
            changed = [k for k in a if a[k] != DEFAULT[k]]
            solved.append(name[:-5] + (f' (corrected: {", ".join(changed)})' if changed else ''))
    print(len(solved), 'tasks:')
    for s in solved:
        print(' ', s)
