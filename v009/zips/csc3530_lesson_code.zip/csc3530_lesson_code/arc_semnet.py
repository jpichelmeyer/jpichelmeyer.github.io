# --- build ---
from arc_utils import load_task, find_objects, show, COLOR_NAMES

def build_net(grid):
    """A semantic network for one grid: object nodes plus relations."""
    objs = find_objects(grid, bg=0)
    nodes = {f'o{i}': o for i, o in enumerate(objs)}
    edges = set()
    for a, oa in nodes.items():
        for b, ob in nodes.items():
            if a == b:
                continue
            if oa['size'] > ob['size']:
                edges.add((a, 'bigger-than', b))
            if oa['color'] == ob['color']:
                edges.add((a, 'same-color', b))
            if oa['bottom'] < ob['top']:
                edges.add((a, 'above', b))
            if oa['right'] < ob['left']:
                edges.add((a, 'left-of', b))
    return nodes, edges

def describe(nodes, edges):
    for n, o in nodes.items():
        print(f'  {n}: {COLOR_NAMES[o["color"]]}, size {o["size"]}')
    for e in sorted(edges):
        print('  ', *e)

# --- compare ---
def compare(net_in, grid_out):
    """Match each input object to what is in the output at its cells."""
    nodes, _ = net_in
    report = []
    for n, o in nodes.items():
        out_colors = {grid_out[r][c] for r, c in o['cells']}
        if out_colors == {o['color']}:
            report.append((n, 'kept', None))
        elif out_colors == {0}:
            report.append((n, 'deleted', None))
        elif len(out_colors) == 1:
            report.append((n, 'recolored', out_colors.pop()))
        else:
            report.append((n, 'changed', None))
    return report

task = load_task('data/training/aabf363d.json')
pair = task['train'][0]
net = build_net(pair['input'])
print('input network:')
describe(*net)
print('what happened to each node:')
for row in compare(net, pair['output']):
    print('  ', row)

# --- rule ---
def roles(nodes):
    by_size = sorted(nodes, key=lambda n: nodes[n]['size'])
    return {'smallest': by_size[0], 'largest': by_size[-1]}

def apply_rule(grid):
    """Rule read off the network comparison: the largest object takes the
    colour of the smallest object, and the smallest object disappears."""
    nodes, _ = build_net(grid)
    r = roles(nodes)
    big, small = nodes[r['largest']], nodes[r['smallest']]
    out = [row[:] for row in grid]
    for y, x in big['cells']:
        out[y][x] = small['color']
    for y, x in small['cells']:
        out[y][x] = 0
    return out

print('rule fits every train pair:',
      all(apply_rule(p['input']) == p['output'] for p in task['train']))
print('test correct:', apply_rule(task['test'][0]['input']) == task['test'][0]['output'])
