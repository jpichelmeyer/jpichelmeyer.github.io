from arc_utils import load_task
from arc_gt import solve

task = load_task('data/training/28bf18c6.json')
for smart in (False, True):
    prog, checks = solve(task, smart)
    print('smart' if smart else 'naive', 'tester:', prog, 'after', checks, 'full checks')
