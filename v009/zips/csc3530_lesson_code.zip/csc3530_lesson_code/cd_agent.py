# Common-sense inference with conceptual-dependency primitives (after Schank).
# --- primitives ---
# Many verbs, few primitive actions. Each primitive knows its consequences.
VERB_TO_PRIMITIVE = {
    'gave': 'ATRANS', 'sold': 'ATRANS', 'handed': 'ATRANS',    # transfer of possession
    'threw': 'PROPEL', 'tossed': 'PROPEL',                     # apply force to move
    'walked': 'PTRANS', 'drove': 'PTRANS',                     # change of location
    'ate': 'INGEST', 'drank': 'INGEST', 'devoured': 'INGEST',  # take into the body
    'told': 'MTRANS', 'showed': 'MTRANS',                      # transfer of information
}

def consequences(prim, actor, obj, to):
    """What becomes true and false: the common-sense knowledge
    attached to each primitive, written once and shared by every verb."""
    if prim == 'ATRANS':
        return {('has', to, obj)}, {('has', actor, obj)}
    if prim == 'PROPEL':
        return {('at', obj, to)}, {('has', actor, obj)}
    if prim == 'PTRANS':
        return {('at', actor, to)}, {('at', actor, 'home')}
    if prim == 'INGEST':
        return {('inside', obj, actor)}, {('exists', obj, 'outside'), ('hungry', actor, None)}
    if prim == 'MTRANS':                     # information is copied, not moved
        return {('knows', to, obj)}, set()
    return set(), set()

# --- story ---
world = {('has', 'john', 'book'), ('has', 'john', 'ball'), ('knows', 'mary', 'news'),
         ('hungry', 'john', None), ('exists', 'apple', 'outside'), ('at', 'john', 'home')}
story = [('john', 'gave', 'book', 'mary'), ('mary', 'told', 'news', 'john'),
         ('john', 'threw', 'ball', 'sue'), ('john', 'devoured', 'apple', None),
         ('john', 'walked', None, 'school')]
for actor, verb, obj, to in story:
    prim = VERB_TO_PRIMITIVE[verb]
    add, delete = consequences(prim, actor, obj, to)
    world = (world - delete) | add
    print(' '.join(w for w in [actor, verb, obj, 'to ' + to if to else ''] if w), f' [{prim}]')

# --- ask ---
def ask(q):
    return 'yes' if q in world else 'no'

for question, fact in [('Does Mary have the book?', ('has', 'mary', 'book')),
                       ('Does John still have the book?', ('has', 'john', 'book')),
                       ('Does Mary still know the news?', ('knows', 'mary', 'news')),
                       ('Does John know the news?', ('knows', 'john', 'news')),
                       ('Is John still hungry?', ('hungry', 'john', None)),
                       ('Is John at home?', ('at', 'john', 'home'))]:
    print(f'{question:32} {ask(fact)}')
