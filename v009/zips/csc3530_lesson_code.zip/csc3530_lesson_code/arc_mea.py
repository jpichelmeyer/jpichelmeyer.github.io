from arc_utils import load_task, find_objects, dims

# --- difference ---
def gap(cells_a, cells_b):
    """Difference measure: empty cells between two objects
    (0 means they touch side by side)."""
    return min(abs(r1 - r2) + abs(c1 - c2) for r1, c1 in cells_a for r2, c2 in cells_b) - 1

# --- operators ---
STEPS = {'up': (-1, 0), 'down': (1, 0), 'left': (0, -1), 'right': (0, 1)}

def shift(cells, step):
    dy, dx = STEPS[step]
    return [(r + dy, c + dx) for r, c in cells]

# --- mea ---
def move_until_touching(grid, mover_color, target_color, trace=False):
    """Means-ends analysis: while there is a difference (a gap), apply the
    operator that reduces it the most."""
    objs = {o['color']: o for o in find_objects(grid, bg=0)}
    mover, target = objs[mover_color]['cells'], objs[target_color]['cells']
    h, w = dims(grid)
    while gap(mover, target) > 0:
        best = min(STEPS, key=lambda s: gap(shift(mover, s), target))
        if gap(shift(mover, best), target) >= gap(mover, target):
            break                                   # no operator helps: give up
        mover = shift(mover, best)
        if trace:
            print(f'  {best:5} -> gap {gap(mover, target)}')
    out = [[0] * w for _ in range(h)]
    for r, c in objs[target_color]['cells']:
        out[r][c] = target_color
    for r, c in mover:
        out[r][c] = mover_color
    return out

task = load_task('data/training/05f2a901.json')
print('train pair 1:')
move_until_touching(task['train'][0]['input'], 2, 8, trace=True)
solve = lambda g: move_until_touching(g, 2, 8)
print('fits every train pair:', all(solve(p['input']) == p['output'] for p in task['train']))
print('test correct:', solve(task['test'][0]['input']) == task['test'][0]['output'])
