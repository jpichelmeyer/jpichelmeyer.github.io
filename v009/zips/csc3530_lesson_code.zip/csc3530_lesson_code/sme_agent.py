# Structure mapping: an analogy is a mapping that preserves relations.
from itertools import permutations

# --- domains ---
# Facts are tuples: (relation, arg, arg). Higher-order facts take facts as args.
SOLAR = {
    ('more-massive', 'sun', 'planet'),
    ('attracts', 'sun', 'planet'),
    ('revolves-around', 'planet', 'sun'),
    ('hotter', 'sun', 'planet'),
    ('yellow', 'sun', None),
    ('cause', ('attracts', 'sun', 'planet'), ('revolves-around', 'planet', 'sun')),
}
ATOM = {
    ('more-massive', 'nucleus', 'electron'),
    ('attracts', 'nucleus', 'electron'),
}

def objects(domain):
    out = set()
    for f in domain:
        for a in f[1:]:
            if isinstance(a, tuple):
                out |= set(objects({a}))
            elif a is not None:
                out.add(a)
    return sorted(out)

# --- map ---
def translate(fact, m):
    if fact is None or isinstance(fact, str):
        return m.get(fact, fact)
    return (fact[0],) + tuple(translate(a, m) for a in fact[1:])

def score(mapping, base, target):
    """Shared relations under the mapping. A matched relation counts 1;
    a relation that sits inside a higher-order relation counts extra,
    because systematic structure is what makes an analogy deep."""
    s = 0
    for f in base:
        if f[0] in ('yellow',):          # attributes of single objects don't count
            continue
        if translate(f, mapping) in target:
            inside = any(isinstance(a, tuple) and a == f for g in base for a in g[1:])
            s += 2 if inside else 1
    return s

def all_mappings(base, target):
    """Every one-to-one pairing of base objects with target objects."""
    bo, to = objects(base), objects(target)
    for p in permutations(to, len(bo)):
        yield dict(zip(bo, p))

# --- infer ---
def candidate_inferences(mapping, base, target):
    """Carry over base facts that belong to the matched causal structure
    but are missing in the target."""
    out = []
    for f in base:
        if f[0] == 'cause':
            cause, effect = f[1], f[2]
            if translate(cause, mapping) in target and translate(effect, mapping) not in target:
                out.append(translate(effect, mapping))
                out.append(translate(f, mapping))
    return out

for m in all_mappings(SOLAR, ATOM):
    print('mapping', m, '-> score', score(m, SOLAR, ATOM))
m = max(all_mappings(SOLAR, ATOM), key=lambda m: score(m, SOLAR, ATOM))
for inf in candidate_inferences(m, SOLAR, ATOM):
    print('infer:', inf)
print('not carried over:', translate(('hotter', 'sun', 'planet'), m), translate(('yellow', 'sun', None), m))
