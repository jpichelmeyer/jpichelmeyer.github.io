# Pattern statistics versus rule induction on number sequences.
from collections import Counter, defaultdict

# --- corpus ---
# "Training data": many sequences that count up by 2 or by 3, starting at 1-20.
corpus = []
for start in range(1, 21):
    for step in (2, 3):
        corpus.append([start + step * i for i in range(6)])

# --- ngram ---
# A statistical model: given the last two numbers, which number most often
# came next in the training data?
table = defaultdict(Counter)
for seq in corpus:
    for a, b, c in zip(seq, seq[1:], seq[2:]):
        table[(a, b)][c] += 1

def ngram_next(seq):
    options = table.get(tuple(seq[-2:]))
    return options.most_common(1)[0][0] if options else None

# --- rule ---
# An induced rule: find the constant difference, check it, extrapolate.
def rule_next(seq):
    d = seq[1] - seq[0]
    if all(b - a == d for a, b in zip(seq, seq[1:])):
        return seq[-1] + d
    return None

# --- compare ---
tests = {'seen pattern':          [4, 6, 8, 10],
         'beyond the data':       [101, 103, 105, 107],
         'a new step size':       [5, 12, 19, 26]}
for name, seq in tests.items():
    print(f'{name:18} {seq} -> n-gram: {ngram_next(seq)},  rule: {rule_next(seq)}')
