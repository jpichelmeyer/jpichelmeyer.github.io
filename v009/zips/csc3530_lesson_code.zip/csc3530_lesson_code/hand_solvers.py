# --- solvers ---
from arc_utils import load_task, check, flip_h, rotate180, hconcat

def solve_67a3c6ac(grid):          # mirror left-right
    return flip_h(grid)

def solve_3c9b0459(grid):          # rotate half a turn
    return rotate180(grid)

def solve_a416b8f3(grid):          # put two copies side by side
    return hconcat(grid, grid)

for tid, solver in [('67a3c6ac', solve_67a3c6ac),
                    ('3c9b0459', solve_3c9b0459),
                    ('a416b8f3', solve_a416b8f3)]:
    task = load_task(f'data/training/{tid}.json')
    print(tid)
    if check(solver, task):
        answer = solver(task['test'][0]['input'])
        print('  test correct?', answer == task['test'][0]['output'])
