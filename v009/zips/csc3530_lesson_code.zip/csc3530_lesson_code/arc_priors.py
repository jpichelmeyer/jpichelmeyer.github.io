import os
from collections import deque
from arc_utils import load_task, dims

# --- gravity ---
def gravity(grid, direction):
    """Every coloured cell slides as far as it can in one direction,
    stopping at the edge or at another cell (stacking up)."""
    g = grid
    turn = {'down': 0, 'left': 1, 'up': 2, 'right': 3}[direction]
    for _ in range(turn):                          # rotate so that "down" is the direction
        g = [list(r) for r in zip(*g[::-1])]
    h, w = dims(g)
    out = [[0] * w for _ in range(h)]
    for c in range(w):
        col = [g[r][c] for r in range(h) if g[r][c] != 0]
        for k, v in enumerate(reversed(col)):
            out[h - 1 - k][c] = v
    for _ in range((4 - turn) % 4):                # rotate back
        out = [list(r) for r in zip(*out[::-1])]
    return out

# --- inside ---
def fill_enclosed(grid, color):
    """Insideness: black cells that cannot reach the border are inside
    something. Paint them."""
    h, w = dims(grid)
    outside = set()
    q = deque((r, c) for r in range(h) for c in range(w)
              if (r in (0, h - 1) or c in (0, w - 1)) and grid[r][c] == 0)
    outside.update(q)
    while q:
        r, c = q.popleft()
        for nr, nc in [(r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)]:
            if 0 <= nr < h and 0 <= nc < w and grid[nr][nc] == 0 and (nr, nc) not in outside:
                outside.add((nr, nc))
                q.append((nr, nc))
    return [[color if v == 0 and (r, c) not in outside else v for c, v in enumerate(row)]
            for r, row in enumerate(grid)]

# --- priors ---
def hypotheses(task):
    """Core-knowledge priors as ready-made hypotheses. The fill colour is
    read off the first train pair (whatever appears that was not there)."""
    for d in ['down', 'up', 'left', 'right']:
        yield f'gravity {d}', lambda g, d=d: gravity(g, d)
    p = task['train'][0]
    new = {v for row in p['output'] for v in row} - {v for row in p['input'] for v in row}
    for c in new:
        yield f'fill enclosed with {c}', lambda g, c=c: fill_enclosed(g, c)

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        task = load_task('data/training/' + name)
        for label, h in hypotheses(task):
            if all(h(p['input']) == p['output'] for p in task['train']):
                if all(h(p['input']) == p['output'] for p in task['test']):
                    solved.append(f'{name[:-5]} ({label})')
                break
    print(len(solved), 'tasks:', ', '.join(solved))
