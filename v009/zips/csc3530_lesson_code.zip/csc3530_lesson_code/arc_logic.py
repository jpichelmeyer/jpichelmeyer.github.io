import os
from arc_utils import load_task, dims

# --- split ---
def split(grid):
    """Cut a grid into two equal halves: at a full line of one colour
    through the middle if there is one, otherwise straight down the middle."""
    h, w = dims(grid)
    mid_col = {grid[r][w // 2] for r in range(h)}
    mid_row = set(grid[h // 2])
    if w % 2 == 1 and len(mid_col) == 1 and mid_col != {0}:      # separator column
        return [row[:w // 2] for row in grid], [row[w // 2 + 1:] for row in grid]
    if h % 2 == 1 and len(mid_row) == 1 and mid_row != {0}:      # separator row
        return grid[:h // 2], grid[h // 2 + 1:]
    if w % 2 == 0 and w >= h:
        return [row[:w // 2] for row in grid], [row[w // 2:] for row in grid]
    if h % 2 == 0:
        return grid[:h // 2], grid[h // 2:]
    return None

# --- learn ---
def learn_truth_table(task):
    """Treat each cell of each half as a proposition (coloured = True).
    Record which output colour goes with each (left, right) combination;
    fail if any combination ever maps to two different outputs."""
    table = {}
    for pair in task['train']:
        halves = split(pair['input'])
        if not halves or dims(halves[0]) != dims(pair['output']):
            return None
        a, b = halves
        for r, row in enumerate(pair['output']):
            for c, v in enumerate(row):
                key = (a[r][c] != 0, b[r][c] != 0)
                if table.setdefault(key, v) != v:
                    return None
    return table

NAMES = {(False, False, False, True): 'AND', (False, True, True, True): 'OR',
         (False, True, True, False): 'XOR', (True, False, False, False): 'NOR',
         (True, True, True, False): 'NAND', (True, False, False, True): 'XNOR'}

def name_of(table):
    bits = tuple(table.get(k, 0) != 0 for k in [(False, False), (False, True), (True, False), (True, True)])
    return NAMES.get(bits, 'other')

def apply(table, grid):
    a, b = split(grid)
    return [[table[(a[r][c] != 0, b[r][c] != 0)] for c in range(len(a[0]))] for r in range(len(a))]

# --- sweep ---
if __name__ == '__main__':
    for name in sorted(os.listdir('data/training')):
        task = load_task('data/training/' + name)
        table = learn_truth_table(task)
        if table and len(table) == 4:
            test = task['test'][0]
            ok = apply(table, test['input']) == test['output']
            print(f'{name[:-5]}: {name_of(table):4}  test {"correct" if ok else "wrong"}')
