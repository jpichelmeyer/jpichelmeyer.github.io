import os, itertools
from arc_utils import (load_task, dims, background, find_objects, crop, crop_object,
                       flip_h, flip_v, transpose, rotate90, rotate180, rotate270,
                       hconcat, vconcat, scale)

# --- primitives ---
def crop_all(g):
    bg = background(g)
    cells = [(r, c) for r, row in enumerate(g) for c, v in enumerate(row) if v != bg]
    rs, cs = [r for r, _ in cells], [c for _, c in cells]
    return crop(g, min(rs), min(cs), max(rs), max(cs))

def largest(g):
    return crop_object(g, max(find_objects(g), key=lambda o: o['size']))

def smallest(g):
    return crop_object(g, min(find_objects(g), key=lambda o: o['size']))

def gravity(g):                     # every non-background cell falls down
    bg, (h, w) = background(g), dims(g)
    out = [[bg] * w for _ in range(h)]
    for c in range(w):
        col = [g[r][c] for r in range(h) if g[r][c] != bg]
        for k, v in enumerate(reversed(col)):
            out[h - 1 - k][c] = v
    return out

PRIMS = {
    'flip_h': flip_h, 'flip_v': flip_v, 'transpose': transpose,
    'rot90': rotate90, 'rot180': rotate180, 'rot270': rotate270,
    'scale2': lambda g: scale(g, 2), 'scale3': lambda g: scale(g, 3),
    'double_w': lambda g: hconcat(g, g), 'double_h': lambda g: vconcat(g, g),
    'mirror_w': lambda g: hconcat(g, flip_h(g)), 'mirror_h': lambda g: vconcat(g, flip_v(g)),
    'tile3': lambda g: vconcat(vconcat(hconcat(hconcat(g, g), g), hconcat(hconcat(g, g), g)),
                               hconcat(hconcat(g, g), g)),
    'left_half': lambda g: [r[:len(r) // 2] for r in g],
    'top_half': lambda g: g[:len(g) // 2],
    'crop_all': crop_all, 'largest': largest, 'smallest': smallest,
    'gravity': gravity,
}

# --- generate ---
def programs(depth=2):
    """Every sequence of up to `depth` primitives, shortest first."""
    for n in range(1, depth + 1):
        yield from itertools.product(PRIMS, repeat=n)

def run(prog, g):
    for name in prog:
        g = PRIMS[name](g)
    return g

# --- test ---
def fits(prog, task, smart):
    """Test a program on every train pair. A smart tester checks the cheap
    thing first: does the first output even have the right size?"""
    try:
        if smart:
            first = task['train'][0]
            if dims(run(prog, first['input'])) != dims(first['output']):
                return False, 'size'
        return all(run(prog, p['input']) == p['output'] for p in task['train']), 'full'
    except Exception:
        return False, 'error'

def solve(task, smart=True):
    full_checks = 0
    for prog in programs():
        ok, how = fits(prog, task, smart)
        full_checks += how == 'full'
        if ok:
            return prog, full_checks
    return None, full_checks

# --- sweep ---
if __name__ == '__main__':
    solved, checks = [], 0
    for name in sorted(os.listdir('data/training')):
        task = load_task('data/training/' + name)
        prog, n = solve(task)
        checks += n
        if prog and all(run(prog, t['input']) == t['output'] for t in task['test']):
            solved.append((name[:-5], ' then '.join(prog)))
    print(f'{len(PRIMS)} primitives, {sum(1 for _ in programs())} programs per task')
    print(f'solved {len(solved)} of 400; full checks needed: {checks}')
    for tid, prog in solved:
        print(f'  {tid}: {prog}')
