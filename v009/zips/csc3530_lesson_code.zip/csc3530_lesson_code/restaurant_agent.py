# Story understanding with a script.
# --- script ---
RESTAURANT = {
    'roles': ['customer', 'waiter', 'cook'],
    'props': ['table', 'menu', 'food', 'bill', 'money'],
    'entry': ['customer is hungry', 'customer has money'],
    'scenes': [   # (event, verbs that signal it)
        ('customer enters', {'went', 'entered', 'walked'}),
        ('customer sits at a table', {'sat'}),
        ('customer reads the menu', {'read', 'looked'}),
        ('customer orders food', {'ordered', 'asked'}),
        ('cook prepares the food', {'cooked', 'prepared'}),
        ('waiter brings the food', {'brought', 'served'}),
        ('customer eats', {'ate', 'enjoyed'}),
        ('customer pays the bill', {'paid', 'tipped'}),
        ('customer leaves', {'left'}),
    ],
    'results': ['customer is not hungry', 'customer has less money', 'restaurant has more money'],
}

# --- match ---
def understand(story, script):
    """Match each sentence to a scene by its verb, then fill in every scene
    that must have happened between the first and last matched scenes.
    A sentence that matches no scene is a possible DEVIATION: scenes
    inferred after it are only guesses."""
    scenes = script['scenes']
    matched, deviation_at = {}, None
    for sentence in story:
        words = set(sentence.lower().strip('.').split())
        hits = [i for i, (event, verbs) in enumerate(scenes) if words & verbs]
        if hits:
            for i in hits:
                matched[i] = sentence
        elif deviation_at is None:
            deviation_at = max(matched) if matched else 0
            print(f'  ! "{sentence}" is not in the script: possible deviation')
    first, last = min(matched), max(matched)
    account = []
    for i in range(first, last + 1):
        if i in matched:
            how = 'stated'
        elif deviation_at is not None and i > deviation_at:
            how = 'UNCERTAIN (after a deviation)'
        else:
            how = 'inferred from the script'
        account.append((scenes[i][0], how))
    return account

# --- use ---
def did_eat(account):
    how = dict(account).get('customer eats', 'not mentioned')
    return {'stated': 'yes', 'inferred from the script': 'yes (inferred)'}.get(how, 'unknown')

for story in [['John went to a restaurant.', 'He ordered lobster.', 'He paid and left a big tip.'],
              ['Mary went to a restaurant.', 'She ordered soup.', 'She waited an hour.', 'She left.']]:
    print(' '.join(story))
    account = understand(story, RESTAURANT)
    for event, how in account:
        print(f'    {event:28} {how}')
    print('  Did they eat?', did_eat(account))
