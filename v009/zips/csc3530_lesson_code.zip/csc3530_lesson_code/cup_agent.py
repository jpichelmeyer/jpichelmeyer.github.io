# Explanation-based learning: prove that an object is a cup, then
# generalize the proof into a new, directly usable rule.
# --- knowledge ---
# Background rules, each learned earlier from one example (in brackets).
RULES = {
    'cup':             [['stable', 'enables-drinking']],   # the definition of a cup
    'stable':          [['flat-bottom']],                  # [a brick]
    'enables-drinking': [['liftable', 'carries-liquids']], # [a glass]
    'liftable':        [['light', 'has-handle']],          # [a briefcase]
    'carries-liquids': [['has-concavity']],                # [a bowl]
}

# --- explain ---
def explain(goal, facts, depth=0):
    """Backward-chain a proof. Returns the proof tree, or None."""
    if goal in facts:
        return goal
    for body in RULES.get(goal, []):
        parts = [explain(g, facts, depth + 1) for g in body]
        if all(parts):
            return (goal, parts)
    return None

def show(tree, depth=0):
    if isinstance(tree, str):
        print('    ' * depth + tree + '   <- observed')
    else:
        print('    ' * depth + tree[0])
        for t in tree[1]:
            show(t, depth + 1)

def leaves(tree):
    return [tree] if isinstance(tree, str) else [l for t in tree[1] for l in leaves(t)]

# --- example ---
mug = {'light', 'has-handle', 'has-concavity', 'flat-bottom',
       'red', 'porcelain', 'has-logo', 'chipped'}
proof = explain('cup', mug)
print('Why is this object a cup?')
show(proof)

# --- generalize ---
# Keep only the observations the proof actually used: that IS the new rule.
learned = sorted(leaves(proof))
print('learned rule: cup <-', ' AND '.join(learned))
print('ignored as irrelevant:', sorted(mug - set(learned)))

def is_cup_fast(obj):
    return set(learned) <= obj

# --- use ---
for name, obj in [('blue plastic cup', {'light', 'has-handle', 'has-concavity', 'flat-bottom', 'blue'}),
                  ('heavy iron pot', {'has-handle', 'has-concavity', 'flat-bottom'}),
                  ('paper cone', {'light', 'has-concavity'})]:
    print(f'{name}: cup? {is_cup_fast(obj)}')
