import os
from arc_utils import (load_task, dims, flip_h, flip_v, transpose, rotate90, rotate180, rotate270)

# --- parts ---
# The parts a tiled output can be built from: the input under one of the
# eight symmetries of a square, or an empty (black) tile.
PARTS = {'id': lambda g: [r[:] for r in g], 'flip_h': flip_h, 'flip_v': flip_v,
         'rot90': rotate90, 'rot180': rotate180, 'rot270': rotate270,
         'transpose': transpose, 'anti': lambda g: rotate180(transpose(g)),
         'blank': lambda g: [[0] * len(g[0]) for _ in g]}

def block(grid, i, j, h, w):
    return [row[j * w:(j + 1) * w] for row in grid[i * h:(i + 1) * h]]

# --- configure ---
def configure(task):
    """Skeleton: the output is an a x b arrangement of tiles, each tile one
    of PARTS applied to the input. Variables: a, b, and the part in each
    slot. Constraint: every train pair must be reproduced exactly."""
    p0 = task['train'][0]
    h, w = dims(p0['input'])
    H, W = dims(p0['output'])
    if H % h or W % w or (H, W) == (h, w):
        return None
    a, b = H // h, W // w
    design = {}
    for i in range(a):
        for j in range(b):
            # values for this slot that satisfy the constraint on EVERY pair
            ok = [name for name, f in PARTS.items()
                  if all(dims(p['output']) == (a * len(p['input']), b * len(p['input'][0])) and
                         f(p['input']) == block(p['output'], i, j, len(p['input']), len(p['input'][0]))
                         for p in task['train'])]
            if not ok:
                return None
            design[(i, j)] = ok[0]
    return a, b, design

def build(config, grid):
    a, b, design = config
    rows = []
    for i in range(a):
        tiles = [PARTS[design[(i, j)]](grid) for j in range(b)]
        for r in range(len(grid)):
            rows.append([v for t in tiles for v in t[r]])
    return rows

# --- demo ---
if __name__ == '__main__':
    task = load_task('data/training/46442a0e.json')
    a, b, design = configure(task)
    print(f'46442a0e: a {a}x{b} arrangement')
    for i in range(a):
        print('   ', '  '.join(f'{design[(i, j)]:8}' for j in range(b)))
    print('test correct:', build((a, b, design), task['test'][0]['input']) == task['test'][0]['output'])

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        cfg = configure(t)
        if cfg and all(build(cfg, p['input']) == p['output'] for p in t['test']):
            solved.append(f'{name[:-5]} ({cfg[0]}x{cfg[1]})')
    print(len(solved), 'tasks:', ', '.join(solved))
