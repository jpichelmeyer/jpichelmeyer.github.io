# Understanding sentences by filling thematic-role frames.
# --- lexicon ---
CATEGORY = {'ashok': 'person', 'david': 'person', 'maria': 'person',
            'pancakes': 'food', 'medicine': 'medicine', 'train': 'vehicle', 'bus': 'vehicle',
            'atlanta': 'place', 'school': 'place', 'book': 'object', 'griddle': 'tool',
            'pills': 'medicine'}

# What each preposition can signal, most likely first.
PREPOSITIONS = {'for': ['beneficiary'], 'with': ['instrument', 'co-agent'],
                'to': ['destination'], 'from': ['source'], 'by': ['conveyance']}

# Verb senses: the roles each sense expects and what may fill them.
VERBS = {
    'made': [('make', {'agent': 'person', 'object': 'food', 'beneficiary': 'person',
                       'instrument': 'tool'})],
    'took': [('ingest', {'agent': 'person', 'object': 'medicine'}),
             ('travel', {'agent': 'person', 'conveyance': 'vehicle', 'object': 'vehicle',
                         'destination': 'place', 'source': 'place'}),
             ('grab', {'agent': 'person', 'object': 'object', 'source': 'person'})],
}

# --- parse ---
def understand(sentence):
    words = sentence.lower().strip('.').replace(' the ', ' ').split()
    subject, verb, obj, rest = words[0], words[1], words[2], words[3:]
    best = None
    for sense, slots in VERBS[verb]:
        frame, score = {'event': sense}, 0
        # subject and object: check them against the sense's constraints
        for role, word in [('agent', subject), ('object', obj)]:
            if slots.get(role) == CATEGORY.get(word):
                frame[role] = word
                score += 1
            elif role in slots:
                score -= 1            # constraint violated: this sense is unlikely
        # prepositional phrases: the preposition proposes roles, the sense disposes
        for prep, word in zip(rest[::2], rest[1::2]):
            for role in PREPOSITIONS.get(prep, []):
                if slots.get(role) == CATEGORY.get(word):
                    frame[role] = word
                    score += 1
                    break
        if best is None or score > best[1]:
            best = (frame, score)
    return best[0]

# --- use ---
for s in ['Ashok made pancakes for David with the griddle.',
          'Ashok took the medicine.',
          'Ashok took the train to Atlanta.',
          'Maria took the book from David.']:
    print(f'{s:48} -> {understand(s)}')
