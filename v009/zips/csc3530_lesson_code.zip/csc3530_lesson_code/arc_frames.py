from arc_utils import load_task, dims, colors, find_objects, flip_h, flip_v

# --- pair frame ---
class PairFrame:
    """One train pair, described by slots. Cheap slots are filled at once;
    expensive ones are computed by if-needed demons the first time asked."""
    DEMONS = {
        'same_size':      lambda p: dims(p.inp) == dims(p.out),
        'size_ratio':     lambda p: (len(p.out) / len(p.inp), len(p.out[0]) / len(p.inp[0])),
        'new_colors':     lambda p: colors(p.out) - colors(p.inp),
        'lost_colors':    lambda p: colors(p.inp) - colors(p.out),
        'n_objects_in':   lambda p: len(find_objects(p.inp, bg=0)),
        'n_objects_out':  lambda p: len(find_objects(p.out, bg=0)),
        'cells_changed':  lambda p: (sum(a != b for ra, rb in zip(p.inp, p.out)
                                         for a, b in zip(ra, rb))
                                     if dims(p.inp) == dims(p.out) else None),
        'out_symmetric':  lambda p: p.out == flip_h(p.out) or p.out == flip_v(p.out),
    }

    def __init__(self, pair):
        self.inp, self.out = pair['input'], pair['output']
        self.slots = {}                       # filled lazily

    def __getitem__(self, slot):
        if slot not in self.slots:
            self.slots[slot] = self.DEMONS[slot](self)
        return self.slots[slot]

# --- task frame ---
class TaskFrame:
    """Generalizes over the pair frames: a slot is an invariant of the task
    if every train pair has the same value for it."""
    def __init__(self, task):
        self.pairs = [PairFrame(p) for p in task['train']]

    def invariants(self, slots):
        found = {}
        for s in slots:
            values = [p[s] for p in self.pairs]
            if all(v == values[0] for v in values):
                found[s] = values[0]
        return found

slots = list(PairFrame.DEMONS)
for tid in ['0ca9ddb6', 'a416b8f3', 'aabf363d', 'd631b094']:
    tf = TaskFrame(load_task(f'data/training/{tid}.json'))
    print(tid)
    for s, v in tf.invariants(slots).items():
        print(f'   {s:14} {v}')
