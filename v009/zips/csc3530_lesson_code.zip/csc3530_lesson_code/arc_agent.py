"""arc_agent.py -- the CSC 3530 semester agent, week 1 version.

Every unit is deliberately simple. Each lesson this term upgrades one
of them. Run it from the folder that holds data/ and arc_utils.py.
"""
import json, os
from arc_utils import (load_task, dims, background, find_objects,
                       flip_h, flip_v, transpose, rotate90, rotate180, rotate270)


# --- perceptor ---
class Perceptor:
    """Raw JSON grids in, a symbolic percept out."""
    def describe(self, grid):
        return {'grid': grid, 'size': dims(grid), 'background': background(grid),
                'objects': find_objects(grid)}

    def perceive(self, task):
        return {'train': [(self.describe(p['input']), self.describe(p['output']))
                          for p in task['train']],
                'test': [self.describe(p['input']) for p in task['test']]}


# --- memory ---
class Memory:
    """Working memory holds the current task; long-term memory holds
    episodes (which method solved which task) and survives between runs."""
    def __init__(self, path='agent_memory.json'):
        self.path = path
        self.working = None
        self.episodes = []
        if os.path.exists(path):
            with open(path) as f:
                self.episodes = json.load(f)

    def remember(self, task_id, methods):
        self.episodes.append({'task': task_id, 'methods': methods})

    def save(self):
        with open(self.path, 'w') as f:
            json.dump(self.episodes, f, indent=1)


# --- decider ---
class Decider:
    """Proposes candidate transformations. Week 1: the eight symmetries
    of a square. Later weeks: rules, search, cases, analogies..."""
    def __init__(self):
        self.hypotheses = [('identity', lambda g: [r[:] for r in g]),
                           ('flip_h', flip_h), ('flip_v', flip_v),
                           ('transpose', transpose), ('rotate90', rotate90),
                           ('rotate180', rotate180), ('rotate270', rotate270),
                           ('anti_transpose', lambda g: rotate180(transpose(g)))]

    def propose(self, percept):
        yield from self.hypotheses


# --- monitor ---
class Monitor:
    """Metacognition, week 1: never trust a hypothesis that fails a train pair."""
    def verify(self, fn, percept):
        try:
            return all(fn(i['grid']) == o['grid'] for i, o in percept['train'])
        except Exception:
            return False


# --- actuator ---
class Actuator:
    """Turns chosen hypotheses into up to two attempts per test input,
    in the ARC Prize submission format."""
    def act(self, chosen, percept):
        answers = []
        for t in percept['test']:
            guesses = [fn(t['grid']) for _, fn in chosen][:2]
            while len(guesses) < 2:
                guesses.append(t['grid'])          # fallback: copy the input
            answers.append({'attempt_1': guesses[0], 'attempt_2': guesses[1]})
        return answers


# --- agent ---
class ARCAgent:
    def __init__(self):
        self.perceptor, self.memory = Perceptor(), Memory()
        self.decider, self.monitor, self.actuator = Decider(), Monitor(), Actuator()

    def solve(self, task_id, task):
        percept = self.perceptor.perceive(task)
        self.memory.working = percept
        chosen = [(n, f) for n, f in self.decider.propose(percept)
                  if self.monitor.verify(f, percept)][:2]
        self.memory.remember(task_id, [n for n, _ in chosen])
        return self.actuator.act(chosen, percept), [n for n, _ in chosen]


# --- run ---
def evaluate(agent, folder='data/training'):
    solved = []
    for name in sorted(os.listdir(folder)):
        task_id = name[:-5]
        task = load_task(os.path.join(folder, name))
        answers, methods = agent.solve(task_id, task)
        right = all(t['output'] in (a['attempt_1'], a['attempt_2'])
                    for t, a in zip(task['test'], answers))
        if right:
            solved.append((task_id, methods[0]))
    return solved


if __name__ == '__main__':
    agent = ARCAgent()
    solved = evaluate(agent)
    print(f'solved {len(solved)} of 400 training tasks')
    for task_id, method in solved:
        print(' ', task_id, method)
