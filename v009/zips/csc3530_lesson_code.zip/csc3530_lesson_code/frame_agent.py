# Frames with facets, inheritance and demons, after McShane et al.'s ontology.
# --- isa ---
ISA = {   # a tiny concept hierarchy: child -> parent
    'surgeon': 'medical-personnel', 'vet': 'medical-personnel', 'nurse': 'medical-personnel',
    'medical-personnel': 'human', 'farmer': 'human', 'human': 'animal', 'dog': 'animal',
    'operating-room': 'medical-building', 'clinic': 'medical-building',
    'medical-building': 'place', 'barn': 'place',
}

def is_a(x, y):
    while x is not None:
        if x == y:
            return True
        x = ISA.get(x)
    return False

# --- frame ---
class Frame:
    """A frame is a named bundle of slots. Each slot has facets:
       default      the typical filler
       sem          the normal type restriction
       relaxable_to what is possible, though unusual
       if_needed    a demon that computes a value only when asked"""
    def __init__(self, name, parent=None, **slots):
        self.name, self.parent, self.slots = name, parent, slots

    def facet(self, slot, facet):
        f = self
        while f is not None:                      # inheritance up the chain
            if slot in f.slots and facet in f.slots[slot]:
                return f.slots[slot][facet]
            f = f.parent
        return None

    def slot_names(self):
        names, f = [], self
        while f is not None:
            names += [s for s in f.slots if s not in names]
            f = f.parent
        return names

EVENT = Frame('event', time={'if_needed': lambda inst: 'some time in the past'})
SURGERY = Frame('surgery', parent=EVENT,
    agent={'default': 'surgeon', 'sem': 'medical-personnel', 'relaxable_to': 'human'},
    theme={'default': 'human', 'sem': 'animal'},
    location={'default': 'operating-room', 'sem': 'medical-building', 'relaxable_to': 'place'})

# --- instance ---
class Instance:
    """A filled-in copy of a frame: one particular event."""
    def __init__(self, frame, **fillers):
        self.frame, self.fillers, self.notes = frame, {}, []
        for slot, value in fillers.items():
            self.fill(slot, value)

    def fill(self, slot, value):
        sem, relax = self.frame.facet(slot, 'sem'), self.frame.facet(slot, 'relaxable_to')
        if sem is None or is_a(value, sem):
            self.fillers[slot] = value
        elif relax and is_a(value, relax):
            self.fillers[slot] = value
            self.notes.append(f'{slot}={value} is possible but unusual (expected a {sem})')
        else:
            self.notes.append(f'{slot}={value} REJECTED: not even a {relax or sem}')

    def get(self, slot):
        if slot in self.fillers:
            return self.fillers[slot], 'stated'
        demon = self.frame.facet(slot, 'if_needed')
        if demon:
            return demon(self), 'computed by demon'
        default = self.frame.facet(slot, 'default')
        return default, 'assumed by default'

    def report(self):
        for slot in self.frame.slot_names():
            value, how = self.get(slot)
            print(f'  {slot:9} {value:16} ({how})')
        for n in self.notes:
            print('  note:', n)

# --- use ---
print('"The vet operated on the dog."')
Instance(SURGERY, agent='vet', theme='dog').report()
print('"The farmer operated on the dog in the barn."')
Instance(SURGERY, agent='farmer', theme='dog', location='barn').report()
print('"The surgery was performed in the dog."')
Instance(SURGERY, location='dog').report()
