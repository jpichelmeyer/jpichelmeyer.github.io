# Semantic networks for a 2x2 visual analogy:  A is to B as C is to ?
# --- network ---
class SemanticNet:
    """Nodes are objects (with attributes); edges are labelled relations."""
    def __init__(self):
        self.nodes = {}            # name -> {attribute: value}
        self.edges = set()         # (from, relation, to)

    def add(self, name, **attrs):
        self.nodes[name] = attrs
        return self

    def relate(self, a, relation, b):
        self.edges.add((a, relation, b))
        return self

    def relations_of(self, name):
        return {(r, b) for a, r, b in self.edges if a == name}

# --- figures ---
A = (SemanticNet().add('x', shape='circle', size='large', fill='no')
                  .add('y', shape='triangle', size='small', fill='yes')
                  .relate('y', 'inside', 'x'))
B = SemanticNet().add('x', shape='circle', size='large', fill='no')
C = (SemanticNet().add('p', shape='square', size='large', fill='no')
                  .add('q', shape='circle', size='small', fill='yes')
                  .relate('q', 'inside', 'p'))
candidates = {
    1: SemanticNet().add('p', shape='square', size='large', fill='no'),
    2: SemanticNet().add('p', shape='square', size='small', fill='no'),
    3: (SemanticNet().add('p', shape='square', size='large', fill='no')
                     .add('q', shape='circle', size='small', fill='yes')
                     .relate('q', 'above', 'p')),
    4: SemanticNet().add('q', shape='circle', size='large', fill='no'),
}

# --- transform ---
# How similar each kind of change is (bigger = more similar), in the
# spirit of the weights in Goel & Joyner's KBAI lectures.
WEIGHTS = {'unchanged': 5, 'size changed': 3, 'fill changed': 3,
           'relation changed': 2, 'shape changed': 1, 'deleted': 1, 'added': 1}

def transform(net1, net2, mapping):
    """Describe how net1 becomes net2, given which object maps to which.
    Objects are described by ROLE (their position in the mapping), not name."""
    changes = []
    for role, (o1, o2) in enumerate(mapping):
        if o2 is None:
            changes.append((role, 'deleted'))
            continue
        a, b = net1.nodes[o1], net2.nodes[o2]
        diffs = [f'{k} changed' for k in a if a[k] != b.get(k)]
        rel1 = {r for r, _ in net1.relations_of(o1)}
        rel2 = {r for r, _ in net2.relations_of(o2)}
        if rel1 != rel2:
            diffs.append('relation changed')
        changes += [(role, d) for d in diffs] or [(role, 'unchanged')]
    return sorted(changes)

def correspond(net1, net2):
    """Pair objects: same shape first, then by order; leftovers are deleted."""
    pairs, used = [], set()
    for o1, a in net1.nodes.items():
        match = next((o2 for o2, b in net2.nodes.items()
                      if o2 not in used and b['shape'] == a['shape']), None)
        if match is None:
            match = next((o2 for o2 in net2.nodes if o2 not in used), None)
        if match:
            used.add(match)
        pairs.append((o1, match))
    return pairs

# --- reason ---
def score(t1, t2):
    """Weighted overlap of two transformations; mismatches cost points."""
    s = sum(WEIGHTS[kind] for role, kind in t1 if (role, kind) in t2)
    return s - len(set(t1) ^ set(t2))

def solve(A, B, C, candidates):
    ab = transform(A, B, correspond(A, B))
    print('A -> B:', ab)
    best = None
    for k, D in candidates.items():
        cd = transform(C, D, correspond(C, D))
        s = score(ab, cd)
        print(f'  C -> {k}: {cd}  score {s}')
        if best is None or s > best[1]:
            best = (k, s)
    return best[0]

print('answer:', solve(A, B, C, candidates))
