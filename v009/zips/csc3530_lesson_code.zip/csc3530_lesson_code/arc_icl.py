import os
from arc_utils import load_task, find_objects, dims, background

# --- features ---
BG = {'black': lambda g: 0 if any(0 in row for row in g) else background(g),
      'majority': background}       # two theories of what the background is

def features(obj, grid):
    h, w = dims(grid)
    solid = obj['size'] == obj['height'] * obj['width']
    return {'color': obj['color'], 'size': obj['size'], 'single_cell': obj['size'] == 1,
            'height': obj['height'], 'width': obj['width'], 'solid_rectangle': solid,
            'touches_edge': obj['top'] == 0 or obj['left'] == 0 or
                            obj['bottom'] == h - 1 or obj['right'] == w - 1}

# --- learner ---
class Concept:
    """Most specific conjunction consistent with the positives so far.
    Each feature is either a set of allowed values or dropped (None)."""
    def __init__(self, first):
        self.allowed = {f: {v} for f, v in first.items()}

    def covers(self, ex):
        return all(vals is None or ex[f] in vals for f, vals in self.allowed.items())

    def positive(self, ex, log):
        for f, vals in self.allowed.items():
            if vals is not None and ex[f] not in vals:
                if len(vals) >= 2 or isinstance(ex[f], bool):   # every value allowed: drop it
                    self.allowed[f] = None
                    log.append(f'drop {f}')
                else:
                    vals.add(ex[f])
                    log.append(f'enlarge {f} to {sorted(vals)}')

    def specificity(self):
        return sum(v is not None for v in self.allowed.values())

    def describe(self):
        return ', '.join(f'{f} in {sorted(v)}' if len(v) > 1 else f'{f} = {next(iter(v))}'
                         for f, v in self.allowed.items() if v is not None)

# --- examples ---
def labelled_objects(pair, bg):
    """Each input object, labelled with the single colour it has in the
    output (or None if it changed in some other way)."""
    out = pair['output']
    for obj in find_objects(pair['input'], bg=BG[bg](pair['input'])):
        cols = {out[r][c] for r, c in obj['cells']}
        yield features(obj, pair['input']), (cols.pop() if len(cols) == 1 else None)

# --- learn ---
def learn(task, bg='black', verbose=False):
    """For each new colour, incrementally learn which objects turn that colour."""
    if any(dims(p['input']) != dims(p['output']) for p in task['train']):
        return None
    concepts, negatives = {}, {}
    for i, pair in enumerate(task['train']):
        for feats, label in labelled_objects(pair, bg):
            if label is None:
                return None
            if label == feats['color']:
                negatives.setdefault('kept', []).append(feats)
                continue
            log = []
            if label not in concepts:
                concepts[label] = Concept(feats)
                log.append('first example')
            else:
                concepts[label].positive(feats, log)
            if verbose and log:
                print(f'  pair {i}, an object becomes {label}: ' + '; '.join(log))
    for feats in negatives.get('kept', []):
        if any(c.covers(feats) for c in concepts.values()):
            return None                  # a concept covers an object that stayed put
    return concepts

def apply(concepts, grid, bg='black'):
    out = [row[:] for row in grid]
    for obj in find_objects(grid, bg=BG[bg](grid)):
        f = features(obj, grid)
        hits = [k for k, c in concepts.items() if c.covers(f)]
        if hits:   # conflict resolution: the most specific concept wins
            k = max(hits, key=lambda k: concepts[k].specificity())
            for r, c in obj['cells']:
                out[r][c] = k
    return out

# --- demo ---
if __name__ == '__main__':
    task = load_task('data/training/d2abd087.json')
    concepts = learn(task, verbose=True)
    for k, c in concepts.items():
        print(f'objects that become {k}: {c.describe()}')
    print('test correct:', apply(concepts, task['test'][0]['input']) == task['test'][0]['output'])

# --- too specific ---
if __name__ == '__main__':
    task = load_task('data/training/aedd82e4.json')
    concepts = learn(task)
    print('aedd82e4, objects that become 1:', concepts[1].describe())
    print('  fits train:', all(apply(concepts, p['input']) == p['output'] for p in task['train']),
          '| test correct:', apply(concepts, task['test'][0]['input']) == task['test'][0]['output'])

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        for bg in BG:                    # if one theory of background fails, try the other
            cs = learn(t, bg)
            if cs and all(apply(cs, p['input'], bg) == p['output'] for p in t['train']):
                if all(apply(cs, p['input'], bg) == p['output'] for p in t['test']):
                    solved.append(f'{name[:-5]} ({bg})')
                break
    print(len(solved), 'tasks:', ', '.join(solved))
