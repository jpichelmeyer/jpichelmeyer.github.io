from arc_utils import load_task, show

task = load_task('data/training/a416b8f3.json')
for i, pair in enumerate(task['train']):
    show(pair['input'], f'train {i} input')
    show(pair['output'], f'train {i} output')
