# Classification with a concept hierarchy: establish, then refine.
# --- hierarchy ---
# node: (parent, features that must hold to ESTABLISH it, typical features)
TREE = {
    'animal':  (None,     {},                                  {}),
    'bird':    ('animal', {'covering': 'feathers'},             {'flies': True, 'size': 'small'}),
    'mammal':  ('animal', {'covering': 'fur'},                  {'flies': False, 'legs': 4}),
    'fish':    ('animal', {'covering': 'scales', 'gills': True}, {'swims': True}),
    'robin':   ('bird',   {'breast': 'red'},                    {'flies': True, 'size': 'small'}),
    'penguin': ('bird',   {'flies': False, 'swims': True},      {'size': 'medium'}),
    'eagle':   ('bird',   {'hooked_beak': True},                {'flies': True, 'size': 'large'}),
    'bat':     ('mammal', {'flies': True},                      {'size': 'small'}),
    'dog':     ('mammal', {'barks': True},                      {'legs': 4}),
}

def children(node):
    return [n for n, (p, _, _) in TREE.items() if p == node]

# --- classify ---
def establishes(node, obs):
    """A node is established if every required feature is observed to hold.
    A feature we have not observed counts as unknown, not as false."""
    need = TREE[node][1]
    if any(f in obs and obs[f] != v for f, v in need.items()):
        return False
    return all(f in obs for f in need)

def typicality(node, obs):
    typ = TREE[node][2]
    known = [f for f in typ if f in obs]
    return sum(obs[f] == typ[f] for f in known) / len(known) if known else None

def classify(obs):
    """Top-down: establish a node, then try to refine it into a child."""
    node, path = 'animal', ['animal']
    while True:
        winners = [c for c in children(node) if establishes(c, obs)]
        if len(winners) != 1:
            return path, winners
        node = winners[0]
        path.append(node)

# --- use ---
def report(obs):
    path, _ = classify(obs)
    line = ' -> '.join(path)
    if len(path) > 1:
        line += f'   (typicality as a {path[1]}: {typicality(path[1], obs):.1f})'
    open_kids = [c for c in children(path[-1])
                 if not any(f in obs and obs[f] != v for f, v in TREE[c][1].items())]
    if open_kids:   # could not refine: say what would decide it
        asks = [f'{c}? need {sorted(f for f in TREE[c][1] if f not in obs)}' for c in open_kids]
        line += '\n      stuck; ' + '; '.join(asks)
    print(line)

report({'covering': 'feathers', 'breast': 'red', 'flies': True, 'size': 'small'})
report({'covering': 'feathers', 'flies': False, 'swims': True, 'size': 'medium'})
report({'covering': 'fur', 'flies': True, 'size': 'small'})
report({'covering': 'feathers', 'size': 'large'})
