import os
from arc_utils import load_task, dims, background

OFFSETS = [(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1)]

# --- induce ---
def induce_rules(task):
    """Propose rules  IF a cell has colour c THEN the cell at offset (dy, dx)
    becomes colour k.  Keep a rule only if it holds every time its
    condition occurs in every train pair (no counterexamples)."""
    seen = {}                                  # (c, dy, dx) -> set of k
    for pair in task['train']:
        inp, out = pair['input'], pair['output']
        if dims(inp) != dims(out):
            return None
        bg = background(inp)
        h, w = dims(inp)
        for r in range(h):
            for c in range(w):
                col = inp[r][c]
                if col == bg:
                    continue
                for dy, dx in OFFSETS:
                    y, x = r + dy, c + dx
                    if 0 <= y < h and 0 <= x < w and (inp[y][x] == bg or (dy, dx) == (0, 0)):
                        seen.setdefault((col, dy, dx), set()).add(out[y][x])
    rules = []
    for (col, dy, dx), ks in seen.items():
        if len(ks) == 1:
            k = ks.pop()
            unchanged = (k == col) if (dy, dx) == (0, 0) else (k == bg)
            if not unchanged:                 # only rules that DO something
                rules.append((col, dy, dx, k))
    return rules

# --- fire ---
def fire(rules, grid):
    """Production cycle: every rule whose condition matches fires once.
    Conflict resolution: rules about the cell itself fire last (they win)."""
    bg = background(grid)
    h, w = dims(grid)
    out = [row[:] for row in grid]
    for col, dy, dx, k in sorted(rules, key=lambda r: (r[1], r[2]) == (0, 0)):
        for r in range(h):
            for c in range(w):
                y, x = r + dy, c + dx
                if grid[r][c] == col and 0 <= y < h and 0 <= x < w:
                    if grid[y][x] == bg or (dy, dx) == (0, 0):
                        out[y][x] = k
    return out

# --- demo ---
if __name__ == '__main__':
    from arc_utils import COLOR_NAMES as N
    task = load_task('data/training/0ca9ddb6.json')
    rules = induce_rules(task)
    for col, dy, dx, k in sorted(rules):
        print(f'IF cell is {N[col]:6} THEN cell at ({dy:+d},{dx:+d}) := {N[k]}')
    ok = all(fire(rules, p['input']) == p['output'] for p in task['train'])
    print('fits train:', ok, '| test correct:',
          fire(rules, task['test'][0]['input']) == task['test'][0]['output'])

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        rs = induce_rules(t)
        if rs and all(fire(rs, p['input']) == p['output'] for p in t['train']):
            if all(fire(rs, p['input']) == p['output'] for p in t['test']):
                solved.append(name[:-5])
    print(len(solved), 'training tasks solved by local rules:', ' '.join(solved))
