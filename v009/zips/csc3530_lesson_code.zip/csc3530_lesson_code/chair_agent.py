# Configuration: refine an abstract design, assigning values under constraints.
# --- design ---
# The plan skeleton: a chair has legs, a seat, and a back. Each component
# has variables with possible values; materials have mass and cost per unit.
MATERIALS = {'pine': (0.6, 2), 'oak': (0.9, 5), 'steel': (1.5, 4), 'plastic': (0.4, 1)}
SKELETON = [   # (component, variable, options), in the order decisions are made
    ('legs', 'count', [4, 3]),
    ('legs', 'material', ['steel', 'oak', 'pine', 'plastic']),
    ('seat', 'material', ['oak', 'pine', 'plastic']),
    ('back', 'material', ['oak', 'pine', 'plastic']),
]
SIZE = {'legs': 1.0, 'seat': 2.0, 'back': 1.5}     # units of material per part

# --- constraints ---
def check(design, spec):
    """Return the first violated constraint, or None. Partial designs are
    checked only on what has been decided so far."""
    mass = cost = 0
    for comp in ('legs', 'seat', 'back'):
        mat = design.get((comp, 'material'))
        if mat is None:
            continue
        n = design.get(('legs', 'count'), 1) if comp == 'legs' else 1
        mass += MATERIALS[mat][0] * SIZE[comp] * n
        cost += MATERIALS[mat][1] * SIZE[comp] * n
    if mass > spec['max_mass']:
        return f'mass {mass:.1f} kg > {spec["max_mass"]}'
    if cost > spec['budget']:
        return f'cost ${cost:.0f} > ${spec["budget"]}'
    if spec.get('outdoor') and design.get(('seat', 'material')) == 'pine':
        return 'pine seat will rot outdoors'
    return None

# --- refine ---
def configure(spec, design=None, depth=0):
    """Assign variables one at a time in skeleton order, checking constraints
    after each assignment and backing up when one is violated."""
    design = design or {}
    if len(design) == len(SKELETON):
        return design
    comp, var, options = SKELETON[len(design)]
    for value in options:
        trial = {**design, (comp, var): value}
        problem = check(trial, spec)
        print('  ' * depth + f'{comp}.{var} = {value}' + (f'   x {problem}' if problem else ''))
        if problem is None:
            done = configure(spec, trial, depth + 1)
            if done:
                return done
    return None

spec = {'max_mass': 7.0, 'budget': 20, 'outdoor': True}
print('spec:', spec)
result = configure(spec)
print('design:', {f'{c}.{v}': x for (c, v), x in result.items()})
