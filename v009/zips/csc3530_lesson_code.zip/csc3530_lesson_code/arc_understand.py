import os
from arc_utils import load_task, find_objects, dims

# --- frame ---
def understand(pair):
    """Describe a train pair as a MOVE event with thematic roles:
    theme (the object that moved), landmark (an object that stayed),
    direction (toward the landmark?), and how far (one step, or until contact)."""
    if dims(pair['input']) != dims(pair['output']):
        return None
    ins = {o['color']: o for o in find_objects(pair['input'], bg=0)}
    outs = {o['color']: o for o in find_objects(pair['output'], bg=0)}
    if set(ins) != set(outs) or len(ins) != 2:
        return None
    moved = [c for c in ins if ins[c]['cells'] != outs[c]['cells']]
    if len(moved) != 1:
        return None
    theme = moved[0]
    landmark = next(c for c in ins if c != theme)
    dy = outs[theme]['top'] - ins[theme]['top']
    dx = outs[theme]['left'] - ins[theme]['left']
    shift = [(r + dy, c + dx) for r, c in ins[theme]['cells']]
    if sorted(shift) != sorted(outs[theme]['cells']):
        return None                                 # it changed shape: not a move
    before, after = gap(ins[theme], ins[landmark]), gap(outs[theme], ins[landmark])
    extent = set()                                  # every reading this pair supports
    if after == 0:
        extent.add('until contact')
    if max(abs(dy), abs(dx)) == 1:
        extent.add('one step')
    return {'event': 'move', 'theme': theme, 'landmark': landmark,
            'toward_landmark': after < before, 'extent': extent}

def gap(a, b):
    return min(abs(r1 - r2) + abs(c1 - c2) for r1, c1 in a['cells'] for r2, c2 in b['cells']) - 1

# --- generalize ---
def common_frame(task, verbose=False):
    """One understanding that fits every pair. Ambiguous slots (a pair that
    supports two readings) are resolved by intersecting across pairs."""
    frames = [understand(p) for p in task['train']]
    if None in frames:
        return None
    keys = ['event', 'theme', 'landmark', 'toward_landmark']
    if any(f[k] != frames[0][k] for f in frames for k in keys):
        return None
    extent = set.intersection(*(f['extent'] for f in frames))
    if verbose:
        for i, f in enumerate(frames):
            print(f'   pair {i + 1}: extent could be {sorted(f["extent"])}')
    if len(extent) != 1:
        return None
    return dict(frames[0], extent=extent.pop())

# --- act ---
def enact(frame, grid):
    """Carry out the understood event on a new grid."""
    objs = {o['color']: o for o in find_objects(grid, bg=0)}
    theme, land = objs[frame['theme']]['cells'], objs[frame['landmark']]
    steps = 1 if frame['extent'] == 'one step' else 30
    for _ in range(steps):
        if gap({'cells': theme}, land) == 0:
            break
        moves = [[(r + dy, c + dx) for r, c in theme] for dy, dx in [(1, 0), (-1, 0), (0, 1), (0, -1),
                                                                    (1, 1), (1, -1), (-1, 1), (-1, -1)]]
        theme = min(moves, key=lambda m: gap({'cells': m}, land))
    out = [[0] * len(grid[0]) for _ in grid]
    for r, c in land['cells']:
        out[r][c] = frame['landmark']
    for r, c in theme:
        out[r][c] = frame['theme']
    return out

# --- demo ---
if __name__ == '__main__':
    for tid in ['dc433765', '05f2a901']:
        task = load_task(f'data/training/{tid}.json')
        print(tid)
        frame = common_frame(task, verbose=True)
        print('   understood as:', frame)
        print('   test correct:', enact(frame, task['test'][0]['input']) == task['test'][0]['output'])
