# Case-based reasoning for routes in a small town: retrieve, adapt, evaluate, store.
from collections import deque

# --- town ---
TOWN = ['.....#....',
        '.###.#.##.',
        '.#.......#',
        '.#.##.##..',
        '....#.....',
        '.##...###.',
        '..........']

def streets(cell):
    r, c = cell
    for dr, dc in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(TOWN) and 0 <= nc < len(TOWN[0]) and TOWN[nr][nc] == '.':
            yield nr, nc

def bfs(a, b):
    """From-scratch route finding (expensive): breadth-first search."""
    prev, q = {a: None}, deque([a])
    while q:
        x = q.popleft()
        if x == b:
            path = []
            while x:
                path.append(x)
                x = prev[x]
            return path[::-1], len(prev)
        for n in streets(x):
            if n not in prev:
                prev[n] = x
                q.append(n)
    return None, len(prev)

# --- cbr ---
LIBRARY = []                     # cases: (start, goal, route)

def dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def retrieve(start, goal):
    return min(LIBRARY, key=lambda case: dist(start, case[0]) + dist(goal, case[1]))

def adapt(case, start, goal):
    """Reuse the old route; patch on short searched legs at each end."""
    head, n1 = bfs(start, case[0])
    tail, n2 = bfs(case[1], goal)
    return head[:-1] + case[2] + tail[1:], n1 + n2

def evaluate(route, start, goal):
    """Is it a real route, and not absurdly longer than a straight shot?"""
    ok = route[0] == start and route[-1] == goal and \
         all(b in streets(a) for a, b in zip(route, route[1:]))
    return ok and len(route) - 1 <= dist(start, goal) + 6

def solve(start, goal):
    if LIBRARY:
        case = retrieve(start, goal)
        route, effort = adapt(case, start, goal)
        if evaluate(route, start, goal):
            print(f'  {start}->{goal}: adapted the case {case[0]}->{case[1]}, '
                  f'{len(route) - 1} steps, {effort} cells searched')
            LIBRARY.append((start, goal, route))          # store
            return route
        print(f'  {start}->{goal}: adapted route has {len(route) - 1} steps: rejected')
    route, effort = bfs(start, goal)
    print(f'  {start}->{goal}: solved from scratch, {len(route) - 1} steps, {effort} cells searched')
    LIBRARY.append((start, goal, route))
    return route

# --- use ---
for trip in [((0, 0), (6, 9)), ((0, 1), (6, 8)), ((1, 0), (5, 9)), ((6, 0), (0, 9))]:
    solve(*trip)
print('cases stored:', len(LIBRARY))
