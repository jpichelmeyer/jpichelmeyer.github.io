# STRIPS planning, and why goals can clobber each other.
from collections import deque

# --- operators ---
# name: (preconditions, add list, delete list)
OPS = {
    'climb-ladder':  ({'on-floor', 'ladder-dry'}, {'on-ladder'}, {'on-floor'}),
    'descend':       ({'on-ladder'}, {'on-floor'}, {'on-ladder'}),
    'paint-ceiling': ({'on-ladder'}, {'ceiling-painted'}, set()),
    'paint-ladder':  ({'on-floor'}, {'ladder-painted'}, {'ladder-dry'}),
}
START = frozenset({'on-floor', 'ladder-dry'})

def apply(state, op):
    pre, add, delete = OPS[op]
    return frozenset((state - delete) | add) if pre <= state else None

# --- plan ---
def plan(state, goals):
    """Forward state-space planning: breadth-first over operator sequences
    until every goal condition holds."""
    frontier, seen = deque([(state, [])]), {state}
    while frontier:
        s, steps = frontier.popleft()
        if goals <= s:
            return steps
        for op in OPS:
            nxt = apply(s, op)
            if nxt is not None and nxt not in seen:
                seen.add(nxt)
                frontier.append((nxt, steps + [op]))
    return None

# --- naive ---
def one_goal_at_a_time(state, goals):
    """Achieve the goals in the order given, each with its own little plan."""
    steps = []
    for g in goals:
        sub = plan(state, {g})
        if sub is None:
            print(f'  cannot achieve {g} from {sorted(state)}')
            return None
        for op in sub:
            state = apply(state, op)
        steps += sub
    return steps

print('goals in order [ladder, ceiling]:')
print('  plan:', one_goal_at_a_time(START, ['ladder-painted', 'ceiling-painted']))
print('goals in order [ceiling, ladder]:')
print('  plan:', one_goal_at_a_time(START, ['ceiling-painted', 'ladder-painted']))

# --- threats ---
def threats(plan_a, plan_b):
    """Steps of plan_a that delete a precondition of some step of plan_b.
    If there are any, plan_a must come after plan_b (or be repaired)."""
    found = []
    for a in plan_a:
        for b in plan_b:
            clobbered = OPS[a][2] & OPS[b][0]
            if clobbered:
                found.append((a, b, clobbered))
    return found

p_ladder, p_ceiling = plan(START, {'ladder-painted'}), plan(START, {'ceiling-painted'})
print('separate plans:', p_ladder, p_ceiling)
for a, b, what in threats(p_ladder, p_ceiling):
    print(f'  threat: {a} deletes {sorted(what)}, which {b} needs, so {a} must come after {b}')
print('joint plan by search:', plan(START, {'ladder-painted', 'ceiling-painted'}))
