# A Soar-flavoured production system: match, propose, decide, and chunk.
# --- match ---
def match(patterns, wm, bindings=None):
    """Yield every set of variable bindings under which all patterns are in
    working memory. Variables start with '?'. ('not', p) means p is absent."""
    bindings = bindings or {}
    if not patterns:
        yield bindings
        return
    first, rest = patterns[0], patterns[1:]
    if first[0] == 'not':
        if not any(True for _ in match([first[1]], wm, bindings)):
            yield from match(rest, wm, bindings)
        return
    for fact in wm:
        if len(fact) != len(first):
            continue
        b = dict(bindings)
        for p, f in zip(first, fact):
            if isinstance(p, str) and p.startswith('?'):
                if b.setdefault(p, f) != f:
                    break
            elif p != f:
                break
        else:
            yield from match(rest, wm, b)

# --- rules ---
# Each rule: name, IF patterns, THEN a proposed operator (may use variables)
RULES = [
    ('throw-strikes',  [('count', 'balls', 3)], 'fastball'),
    ('fool-a-lefty',   [('batter', 'left')], 'curveball'),
    ('walk-a-slugger', [('batter-skill', 'strong'), ('base', 'first', 'empty'),
                        ('outs', '?n')], 'intentional-walk'),
    ('hold-runner',    [('base', '?b', 'runner'), ('not', ('base', 'first', 'empty'))], 'pickoff'),
]

def propose(wm, rules):
    """Elaboration phase: fire every matching rule, collect proposals."""
    proposals = {}
    for name, conds, op in rules:
        for b in match(conds, wm):
            proposals.setdefault(op, []).append(name)
            break
    return proposals

# --- decide ---
EPISODES = [   # long-term episodic memory: what worked before
    ({('batter', 'left'), ('count', 'balls', 3), ('batter-skill', 'strong')}, 'intentional-walk'),
    ({('batter', 'right'), ('count', 'balls', 3)}, 'fastball'),
]
PREFERENCES = []   # preference rules: IF patterns THEN prefer an operator

def decide(wm):
    proposals = propose(wm, RULES)
    print('  proposals:', proposals)
    if len(proposals) == 1:
        return next(iter(proposals))
    for name, conds, op in PREFERENCES:          # does a learned rule break the tie?
        if op in proposals and any(True for _ in match(conds, wm)):
            print(f'  tie broken by {name}')
            return op
    # IMPASSE: several operators, no knowledge to choose between them.
    print('  impasse! consulting episodic memory')
    best = max(EPISODES, key=lambda ep: len(ep[0] & wm))
    choice = best[1] if best[1] in proposals else sorted(proposals)[0]
    # CHUNKING: save how the impasse was resolved as a new preference rule,
    # so this situation never causes an impasse again.
    chunk = ('chunk-1', sorted(best[0] & wm), choice)
    PREFERENCES.append(chunk)
    print('  learned', chunk)
    return choice

# --- run ---
situation = {('batter', 'left'), ('batter-skill', 'strong'), ('count', 'balls', 3),
             ('outs', 2), ('base', 'first', 'empty'), ('base', 'second', 'runner')}
for at_bat in (1, 2):
    print(f'at-bat {at_bat}:')
    print('  pitch:', decide(situation))
