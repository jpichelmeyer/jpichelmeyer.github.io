# Pathfinding guided by the difference to the goal: greedy best-first vs A*.
import heapq

MAZE = ['S...#.....',
        '.##.#.###.',
        '.#..#...#.',
        '.#.####.#.',
        '.#......#G',
        '.########.',
        '..........']
START, GOAL = (0, 0), (4, 9)

def neighbours(cell):
    r, c = cell
    for dr, dc in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < len(MAZE) and 0 <= nc < len(MAZE[0]) and MAZE[nr][nc] != '#':
            yield nr, nc

def difference(cell):                       # Manhattan distance to the goal
    return abs(cell[0] - GOAL[0]) + abs(cell[1] - GOAL[1])

def search(use_cost):
    """Always expand the cell with the smallest score.
    greedy (means-ends): score = difference still to remove
    A*:                  score = steps taken so far + difference"""
    frontier = [(difference(START), 0, START, [START])]
    done = set()
    while frontier:
        _, cost, cell, path = heapq.heappop(frontier)
        if cell == GOAL:
            return path, len(done)
        if cell in done:
            continue
        done.add(cell)
        for nxt in neighbours(cell):
            if nxt not in done:
                score = difference(nxt) + (cost + 1 if use_cost else 0)
                heapq.heappush(frontier, (score, cost + 1, nxt, path + [nxt]))

for name, use_cost in [('greedy', False), ('A*', True)]:
    path, expanded = search(use_cost)
    print(f'{name:6}: path of {len(path) - 1} steps, {expanded} cells expanded')
    for r, row in enumerate(MAZE):
        print('   ', ''.join('*' if (r, c) in path and ch == '.' else ch for c, ch in enumerate(row)))
