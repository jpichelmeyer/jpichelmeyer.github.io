import os
from arc_utils import load_task, dims
from arc_gt import PRIMS, run

# --- diagnose ---
def diagnose(got, want):
    """Localize the fault in a wrong answer. Returns the kind of fault and,
    where possible, the information needed to repair it."""
    if not got or not got[0]:
        return ('crashed', None)
    if dims(got) != dims(want):
        return ('wrong size', None)
    diff = [(r, c) for r in range(len(want)) for c in range(len(want[0])) if got[r][c] != want[r][c]]
    if not diff:
        return ('correct', None)
    mapping = {}
    for r, c in diff:
        if mapping.setdefault(got[r][c], want[r][c]) != want[r][c]:
            return ('wrong cells', len(diff))
    # every wrong cell of colour x should have been colour y: a colour fault,
    # but only if no correct cell of colour x would be broken by the fix
    if any(got[r][c] in mapping for r in range(len(got)) for c in range(len(got[0]))
           if (r, c) not in diff):
        return ('wrong cells', len(diff))
    return ('wrong colours', mapping)

# --- repair ---
def repair(task):
    """Take each one-step program whose answers have the right SIZE on every
    train pair, diagnose its errors, and if every pair shows the same colour
    fault, repair it by appending a recolouring step."""
    for prog in [()] + [(name,) for name in PRIMS]:      # () = leave the grid as it is
        faults = []
        for p in task['train']:
            try:
                got = run(prog, p['input'])
            except Exception:
                got = None
            faults.append(diagnose(got, p['output']))
        kinds = {k for k, _ in faults}
        if kinds == {'correct'}:
            return prog, None, faults
        if kinds <= {'correct', 'wrong colours'}:
            mapping = {}
            for k, m in faults:
                if k == 'wrong colours':
                    mapping.update(m)
            fixed = lambda g, prog=prog, m=mapping: [[m.get(v, v) for v in row] for row in run(prog, g)]
            if all(fixed(p['input']) == p['output'] for p in task['train']):
                return prog, mapping, faults
    return None, None, None

# --- demo ---
if __name__ == '__main__':
    for tid, prog in [('7468f01a', ('flip_h',)), ('a740d043', ('crop_all',)),
                      ('d511f180', ()), ('3c9b0459', ('flip_h',))]:
        task = load_task(f'data/training/{tid}.json')
        p = task['train'][0]
        print(f'{tid}, program {prog or "identity"}:', diagnose(run(prog, p['input']), p['output']))

# --- sweep ---
if __name__ == '__main__':
    fixed = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        prog, mapping, faults = repair(t)
        if prog is not None and mapping:
            f = lambda g: [[mapping.get(v, v) for v in row] for row in run(prog, g)]
            if all(f(p['input']) == p['output'] for p in t['test']):
                fixed.append(f'{name[:-5]} ({prog[0] if prog else "identity"} + recolour {mapping})')
    print(len(fixed), 'tasks repaired after diagnosis:')
    for s in fixed:
        print(' ', s)
