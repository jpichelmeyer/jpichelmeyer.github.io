import os
from collections import Counter
from arc_utils import load_task, dims, colors, find_objects, flip_h, flip_v, transpose

# --- features ---
def features(g):
    """A feature vector for a whole input grid."""
    objs = find_objects(g, bg=0)
    cnt = Counter(v for row in g for v in row if v != 0)
    return {
        'mirror_lr': g == flip_h(g), 'mirror_ud': g == flip_v(g),
        'diag_sym': dims(g)[0] == dims(g)[1] and g == transpose(g),
        'n_colors': len(colors(g) - {0}), 'n_objects': len(objs),
        'top_color': cnt.most_common(1)[0][0] if cnt else 0,
        'rare_color': cnt.most_common()[-1][0] if cnt else 0,
        'shape': tuple(tuple(v != 0 for v in row) for row in g),   # the mask itself
    }

# --- stump ---
def learn_stump(task):
    """Classification task? (outputs come from a small set of answers).
    Find ONE feature whose value predicts the answer with no exceptions."""
    labels = [str(p['output']) for p in task['train']]
    if len(set(labels)) == len(labels):            # every answer different: not classification
        return None
    answers = {str(p['output']): p['output'] for p in task['train']}
    feats = [features(p['input']) for p in task['train']]
    for f in feats[0]:
        table = {}
        if all(table.setdefault(fv[f], lab) == lab for fv, lab in zip(feats, labels)):
            if len(table) > 1:                     # the feature must actually split
                return f, {v: answers[lab] for v, lab in table.items()}
    return None

def predict(stump, grid):
    f, table = stump
    return table.get(features(grid)[f])

# --- demo ---
if __name__ == '__main__':
    task = load_task('data/training/44f52bb0.json')
    f, table = learn_stump(task)
    print('44f52bb0 is decided by', f, {k: v for k, v in table.items()})

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        stump = learn_stump(t)
        if stump and all(predict(stump, p['input']) == p['output'] for p in t['test']):
            solved.append(f'{name[:-5]} ({stump[0]})')
    print(len(solved), 'tasks:', ', '.join(solved))
