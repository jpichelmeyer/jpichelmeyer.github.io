import os
from arc_utils import load_task, dims, colors

# --- constraints ---
def period_classes(h, w, p, q):
    """Constraint: the picture repeats every p rows and q columns, so all
    cells with the same (row mod p, col mod q) must have the same colour."""
    return lambda r, c: (r % p, c % q)

def mirror_classes(h, w, p, q):
    """Constraint: the picture is symmetric left-right and top-bottom
    (about its centre, offset by p and q), so mirror cells match."""
    def key(r, c):
        rr, cc = min(r, h - 1 - r + p), min(c, w - 1 - c + q)
        return (rr, cc)
    return key

# --- propagate ---
def complete(grid, mask, family, p, q):
    """Group cells by the constraint; each group must share one colour.
    Known cells propagate their colour to masked cells in the same group.
    Fails on a contradiction or if some masked group has no known cell."""
    h, w = dims(grid)
    key = family(h, w, p, q)
    value = {}
    for r in range(h):
        for c in range(w):
            if grid[r][c] != mask:
                k = key(r, c)
                if value.setdefault(k, grid[r][c]) != grid[r][c]:
                    return None                  # contradiction: constraint is wrong
    out = [row[:] for row in grid]
    for r in range(h):
        for c in range(w):
            if grid[r][c] == mask:
                k = key(r, c)
                if k not in value:
                    return None                  # nothing to propagate from
                out[r][c] = value[k]
    return out

def masked_box(grid, mask):
    cells = [(r, c) for r, row in enumerate(grid) for c, v in enumerate(row) if v == mask]
    rs, cs = [r for r, _ in cells], [c for _, c in cells]
    return min(rs), min(cs), max(rs), max(cs)

# --- solve ---
def solve(grid, mask, want_patch):
    """Try the simplest constraints first: small periods, then mirror
    symmetries. Return the whole completed grid, or just the hidden patch."""
    h, w = dims(grid)
    periods = sorted(((p, q) for p in range(1, h) for q in range(1, w)), key=lambda pq: pq[0] * pq[1])
    options = [(period_classes, p, q) for p, q in periods]
    options += [(mirror_classes, p, q) for p in range(-3, 4) for q in range(-3, 4)]
    for family, p, q in options:
        full = complete(grid, mask, family, p, q)
        if full is not None:
            if want_patch:
                t, l, b, r = masked_box(grid, mask)
                full = [row[l:r + 1] for row in full[t:b + 1]]
            return full, f'{family.__name__} {(p, q)}'
    return None, None

def mask_color(task):
    """The colour that hides things: present in every input, absent from outputs."""
    cands = set.intersection(*(colors(p['input']) - colors(p['output']) for p in task['train']))
    return min(cands) if cands else 0

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        task = load_task('data/training/' + name)
        m = mask_color(task)
        if not all(any(m in row for row in p['input']) for p in task['train'] + task['test']):
            continue
        # decided from the TRAIN pairs only: is the answer the whole grid or the patch?
        want_patch = any(dims(p['input']) != dims(p['output']) for p in task['train'])
        results = [solve(p['input'], m, want_patch) for p in task['train'] + task['test']]
        if all(out == p['output'] for (out, _), p in zip(results, task['train'] + task['test'])):
            solved.append(f'{name[:-5]} ({results[-1][1]})')
    print(len(solved), 'tasks:')
    for s in solved:
        print(' ', s)
