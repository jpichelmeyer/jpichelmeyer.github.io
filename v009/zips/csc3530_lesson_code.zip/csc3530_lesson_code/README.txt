CSC 3530 lesson code
====================

Every program from the lesson pages, in one folder. Copy the files you
need into your project folder (next to arc_utils.py and data/).
Files starting with arc_ are ARC experiments; run them from the project
folder. The others are the small, self-contained lesson agents.

Some ARC files import from others (arc_cbr.py and arc_diagnose.py use
arc_gt.py; arc_meta.py uses most of them), so keep them together.

shared helpers:
    arc_utils.py

week 1: Situated Agent Model (SAM):
    arc_agent.py
    sequence_agent.py

week 1: Setup:
    draw.py
    hello_agent.py

week 1: ARC-AGI:
    first_look.py
    hand_solvers.py

week 1: Semantic networks:
    arc_semnet.py
    raven_agent.py

week 2: Frames:
    arc_frames.py
    frame_agent.py

week 2: Production systems:
    arc_rules.py
    pitcher_agent.py

week 3: Generate and test:
    arc_gt.py
    arc_gt_demo.py
    maze_agent.py
    river_agent.py

week 3: Means-ends analysis:
    arc_mea.py
    blocks_agent.py
    maze_mea.py

week 4: Logic:
    arc_logic.py
    logic_agent.py

week 4: Planning:
    arc_plan.py
    arc_plan_demo.py
    ladder_agent.py

week 6: Learning by recording cases:
    arc_patch_cases.py
    blocks_cases.py

week 6: Case-based reasoning:
    arc_cbr.py
    route_cbr.py

week 7: Incremental concept learning:
    arc_icl.py
    arch_agent.py

week 7: Classification:
    animal_classifier.py
    arc_classify.py

week 8: Explanation-based learning:
    arc_ebl.py
    cup_agent.py

week 8: Analogical reasoning:
    arc_analogy.py
    sme_agent.py

week 9: Understanding:
    arc_understand.py
    roles_agent.py

week 9: Common-sense reasoning:
    arc_priors.py
    cd_agent.py

week 11: Scripts:
    arc_script.py
    restaurant_agent.py

week 11: Constraint propagation:
    arc_complete.py
    sudoku_agent.py

week 12: Configuration:
    arc_config.py
    chair_agent.py

week 12: Diagnosis:
    arc_diagnose.py
    doctor_agent.py

week 13: Learning by correcting mistakes:
    arc_blame.py
    cup_mistakes.py

week 13: Meta-reasoning:
    arc_meta.py
    strategy_agent.py

week 14: Symbolic KBAI vs modern LLMs:
    arc_hybrid.py
    ngram_vs_rules.py
