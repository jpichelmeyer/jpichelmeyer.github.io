import os
from collections import Counter
from arc_utils import load_task, dims, find_objects, COLOR_NAMES

# --- skeletons ---
# Program skeletons with one colour constant c.
def fill(g, c):                       # every cell becomes c
    return [[c] * len(g[0]) for _ in g]

def paint_shapes(g, c):               # every non-black cell becomes c
    return [[c if v else 0 for v in row] for row in g]

def single_cell(g, c):                # the answer is one cell of colour c
    return [[c]]

def crop_color(g, c):                 # cut out the box around colour c
    cells = [(r, x) for r, row in enumerate(g) for x, v in enumerate(row) if v == c]
    rs, cs = [r for r, _ in cells], [x for _, x in cells]
    return [row[min(cs):max(cs) + 1] for row in g[min(rs):max(rs) + 1]]

def keep_only(g, c):                  # erase every colour except c
    return [[v if v == c else 0 for v in row] for row in g]

SKELETONS = {'fill': fill, 'paint_shapes': paint_shapes, 'single_cell': single_cell,
             'crop_color': crop_color, 'keep_only': keep_only}

# --- roles ---
# Ways to EXPLAIN where a colour comes from, using what the input shows.
def counts(g):
    return Counter(v for row in g for v in row if v != 0)

ROLES = {
    'most common colour':   lambda g: counts(g).most_common(1)[0][0],
    'least common colour':  lambda g: counts(g).most_common()[-1][0],
    'colour of the largest object':  lambda g: max(find_objects(g, bg=0), key=lambda o: o['size'])['color'],
    'colour of the smallest object': lambda g: min(find_objects(g, bg=0), key=lambda o: o['size'])['color'],
    'colour in the top-left corner': lambda g: g[0][0],
}

# --- explain ---
def explain_pair(pair):
    """Explain ONE train pair: find a skeleton and constant that reproduce
    it, then every role that accounts for that constant."""
    found = []
    for sname, sk in SKELETONS.items():
        for c in range(10):
            try:
                fits = sk(pair['input'], c) == pair['output']
            except ValueError:              # e.g. colour c is not in the grid
                fits = False
            if fits:
                for rname, role in ROLES.items():
                    try:
                        if role(pair['input']) == c:
                            found.append((sname, c, rname))
                    except (ValueError, IndexError):
                        pass
    return found

# --- generalize ---
def learn(task, verbose=False):
    """Explain the first pair; generalize each explanation by replacing the
    constant with its role; keep the first one that holds on every pair."""
    chosen = None
    for sname, c, rname in explain_pair(task['train'][0]):
        rule = lambda g, s=SKELETONS[sname], r=ROLES[rname]: s(g, r(g))
        try:
            ok = all(rule(p['input']) == p['output'] for p in task['train'][1:])
        except (ValueError, IndexError):
            ok = False
        if verbose:
            print(f'  {sname}({COLOR_NAMES[c]}) because {COLOR_NAMES[c]} is the {rname}: '
                  + ('holds on every pair' if ok else 'fails on another pair'))
        if ok and chosen is None:
            chosen = rule
    return chosen

# --- demo ---
if __name__ == '__main__':
    for tid in ['5582e5ca', 'be94b721']:
        task = load_task(f'data/training/{tid}.json')
        print(tid)
        rule = learn(task, verbose=True)
        print('  test correct:', rule(task['test'][0]['input']) == task['test'][0]['output'])

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        r = learn(t)
        if r and all(r(p['input']) == p['output'] for p in t['test']):
            solved.append(name[:-5])
    print(len(solved), 'tasks:', ' '.join(solved))
