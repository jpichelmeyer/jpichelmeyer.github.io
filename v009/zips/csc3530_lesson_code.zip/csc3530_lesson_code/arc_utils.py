"""arc_utils.py -- small helpers shared by every CSC 3530 ARC agent.

Put this file next to your agent code. Grids are plain lists of lists of
ints 0-9 (row-major: grid[row][col]), exactly as they appear in the
ARC-AGI JSON files.
"""
import json
from collections import Counter, deque

COLOR_NAMES = ['black', 'blue', 'red', 'green', 'yellow',
               'grey', 'magenta', 'orange', 'azure', 'maroon']


# ------------------------------------------------------------- loading
def load_task(path):
    """Load one ARC task file. Returns {'train': [...], 'test': [...]},
    where each item is {'input': grid, 'output': grid}."""
    with open(path) as f:
        return json.load(f)


# ------------------------------------------------------------- looking
def show(grid, title=None):
    """Print a grid with '.' for black (0) so shapes stand out."""
    if title:
        print(title)
    for row in grid:
        print(' '.join('.' if v == 0 else str(v) for v in row))
    print()


def dims(grid):
    return len(grid), len(grid[0])


def same(a, b):
    return a == b


def copy(grid):
    return [row[:] for row in grid]


def blank(h, w, color=0):
    return [[color] * w for _ in range(h)]


def colors(grid):
    """Set of colours that appear in a grid."""
    return {v for row in grid for v in row}


def background(grid):
    """Guess the background: the most common colour."""
    return Counter(v for row in grid for v in row).most_common(1)[0][0]


# ------------------------------------------------------------- objects
def find_objects(grid, bg=None, diagonal=False, by_color=True):
    """Connected groups of non-background cells.

    Returns a list of dicts with keys:
      color  (int, or None if multi-coloured), cells (list of (r, c)),
      size, top, left, bottom, right, height, width
    """
    if bg is None:
        bg = background(grid)
    h, w = dims(grid)
    seen = set()
    steps = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if diagonal:
        steps += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    objects = []
    for r in range(h):
        for c in range(w):
            if grid[r][c] == bg or (r, c) in seen:
                continue
            col = grid[r][c]
            cells, queue = [], deque([(r, c)])
            seen.add((r, c))
            while queue:
                y, x = queue.popleft()
                cells.append((y, x))
                for dy, dx in steps:
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and (ny, nx) not in seen:
                        v = grid[ny][nx]
                        if v != bg and (v == col or not by_color):
                            seen.add((ny, nx))
                            queue.append((ny, nx))
            rows = [y for y, _ in cells]
            cols = [x for _, x in cells]
            cset = {grid[y][x] for y, x in cells}
            objects.append(dict(
                color=col if len(cset) == 1 else None, cells=cells,
                size=len(cells), top=min(rows), left=min(cols),
                bottom=max(rows), right=max(cols),
                height=max(rows) - min(rows) + 1, width=max(cols) - min(cols) + 1))
    return objects


def crop(grid, top, left, bottom, right):
    return [row[left:right + 1] for row in grid[top:bottom + 1]]


def crop_object(grid, obj):
    return crop(grid, obj['top'], obj['left'], obj['bottom'], obj['right'])


# ------------------------------------------------------------- transforms
def flip_h(grid):        # mirror left <-> right
    return [row[::-1] for row in grid]


def flip_v(grid):        # mirror top <-> bottom
    return [row[:] for row in grid[::-1]]


def transpose(grid):
    return [list(col) for col in zip(*grid)]


def rotate90(grid):      # clockwise
    return [list(col) for col in zip(*grid[::-1])]


def rotate180(grid):
    return flip_v(flip_h(grid))


def rotate270(grid):
    return rotate90(rotate180(grid))


def recolor(grid, mapping):
    return [[mapping.get(v, v) for v in row] for row in grid]


def hconcat(a, b):
    return [ra + rb for ra, rb in zip(a, b)]


def vconcat(a, b):
    return [r[:] for r in a] + [r[:] for r in b]


def scale(grid, k):
    out = []
    for row in grid:
        big = [v for v in row for _ in range(k)]
        out.extend([big[:] for _ in range(k)])
    return out


# ------------------------------------------------------------- testing
def check(solver, task, verbose=True):
    """Run solver(grid) on every training pair. Returns True if all match."""
    ok = True
    for i, pair in enumerate(task['train']):
        try:
            got = solver(pair['input'])
        except Exception as e:          # a crashing guess is a wrong guess
            got = None
            if verbose:
                print(f'  train {i}: error {e!r}')
        match = got == pair['output']
        ok = ok and match
        if verbose:
            print(f'  train {i}: {"PASS" if match else "fail"}')
    return ok
