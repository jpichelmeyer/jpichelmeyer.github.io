import os
from arc_utils import load_task, find_objects, dims

# --- roles ---
def ranks(objs, key):
    """Each object's rank on some measure (0 = smallest). Ties share a rank."""
    values = sorted({key(o) for o in objs})
    return [values.index(key(o)) for o in objs]

RELATIONS = {
    'rank by size':      lambda o: o['size'],
    'rank by height':    lambda o: o['height'],
    'rank by width':     lambda o: o['width'],
    'rank left-to-right': lambda o: o['left'],
    'rank top-to-bottom': lambda o: o['top'],
}

def roles(grid, relation, reverse):
    objs = find_objects(grid, bg=0)
    r = ranks(objs, RELATIONS[relation])
    if reverse and r:                       # count from the other end (0 = largest)
        top = max(r)
        r = [top - x for x in r]
    return objs, r

# --- map ---
def learn_mapping(task):
    """Find a relational role that maps consistently onto output colours:
    in every train pair, the object in role k becomes colour c_k."""
    if any(dims(p['input']) != dims(p['output']) for p in task['train']):
        return None
    for relation in RELATIONS:
        for reverse in (True, False):
            table, ok = {}, True
            for p in task['train']:
                objs, r = roles(p['input'], relation, reverse)
                for o, k in zip(objs, r):
                    out = {p['output'][y][x] for y, x in o['cells']}
                    if len(out) != 1 or table.setdefault(k, min(out)) != min(out):
                        ok = False
            if ok and table:
                return relation, reverse, table
    return None

def transfer(mapping, grid):
    relation, reverse, table = mapping
    objs, r = roles(grid, relation, reverse)
    out = [row[:] for row in grid]
    for o, k in zip(objs, r):
        if k not in table:
            return None               # a role the train pairs never showed
        for y, x in o['cells']:
            out[y][x] = table[k]
    return out

# --- demo ---
if __name__ == '__main__':
    task = load_task('data/training/08ed6ac7.json')
    mapping = learn_mapping(task)
    print('08ed6ac7:', mapping[0], '(largest first)' if mapping[1] else '', '-> colours', mapping[2])
    print('test correct:', transfer(mapping, task['test'][0]['input']) == task['test'][0]['output'])

# --- sweep ---
if __name__ == '__main__':
    solved = []
    for name in sorted(os.listdir('data/training')):
        t = load_task('data/training/' + name)
        m = learn_mapping(t)
        if m and all(transfer(m, p['input']) == p['output'] for p in t['train'] + t['test']):
            solved.append(f'{name[:-5]} ({m[0]})')
    print(len(solved), 'tasks:', ', '.join(solved))
