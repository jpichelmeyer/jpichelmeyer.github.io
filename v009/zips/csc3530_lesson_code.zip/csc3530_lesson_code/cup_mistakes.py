# Learning by correcting mistakes: blame assignment on a concept that
# classified something wrongly (after Goel & Joyner's cup example).
# --- rule ---
rule = {'require': {'has-handle', 'has-concavity'}, 'forbid': set()}

def is_cup(obj):
    return rule['require'] <= obj and not (rule['forbid'] & obj)

# --- experience ---
# Objects the agent met, with what they really turned out to be.
experience = [
    ({'has-handle', 'has-concavity', 'light', 'handle-on-side', 'porcelain'}, True),
    ({'has-handle', 'has-concavity', 'light', 'handle-on-side', 'plastic'}, True),
    ({'has-handle', 'has-concavity', 'heavy', 'handle-on-top', 'metal'}, False),   # a pail
    ({'has-handle', 'has-concavity', 'light', 'handle-on-top', 'plastic'}, False), # a basket
    ({'has-handle', 'has-concavity', 'light', 'handle-on-side', 'metal'}, True),
]

# --- blame ---
def mistakes():
    fp = [o for o, truth in experience if is_cup(o) and not truth]   # wrongly accepted
    fn = [o for o, truth in experience if not is_cup(o) and truth]   # wrongly rejected
    tp = [o for o, truth in experience if is_cup(o) and truth]
    return fp, fn, tp

def assign_blame(fp, tp):
    """Suspicious false-success features: in EVERY false positive and in NO
    true positive. Forbidding any of them would fix the mistakes without
    breaking the successes."""
    common_fp = set.intersection(*fp)
    in_any_tp = set.union(*tp) if tp else set()
    return common_fp - in_any_tp

fp, fn, tp = mistakes()
print('rule:', rule)
print('false positives:', len(fp), '| false negatives:', len(fn))
suspects = assign_blame(fp, tp)
print('suspicious features:', suspects)

# --- correct ---
rule['forbid'] |= suspects
fp, fn, tp = mistakes()
print('corrected rule:', rule)
print('false positives:', len(fp), '| false negatives:', len(fn))
