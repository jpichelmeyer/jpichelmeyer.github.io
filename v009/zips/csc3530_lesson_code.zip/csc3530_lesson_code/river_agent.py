# Generate and test on the guards-and-prisoners river crossing.
# Three guards and three prisoners must cross a river in a boat that holds
# one or two people. Prisoners may never outnumber guards on either bank
# (unless no guards are there).
from collections import deque

# --- state ---
# A state is (guards on left, prisoners on left, boat on left?)
START, GOAL = (3, 3, True), (0, 0, False)
LOADS = [(1, 0), (2, 0), (0, 1), (0, 2), (1, 1)]   # (guards, prisoners) in boat

# --- generate ---
def generate(state):
    """Every successor reachable with one boat trip (no checking)."""
    g, p, left = state
    sign = -1 if left else 1
    for dg, dp in LOADS:
        yield (g + sign * dg, p + sign * dp, not left), (dg, dp)

# --- test ---
def legal(state):
    g, p, _ = state
    if not (0 <= g <= 3 and 0 <= p <= 3):
        return False
    right_g, right_p = 3 - g, 3 - p
    return (g == 0 or g >= p) and (right_g == 0 or right_g >= right_p)

# --- search ---
def solve(smart):
    """Breadth-first generate and test. A 'smart' tester also rejects
    states we have already seen; a naive one only checks legality."""
    frontier, seen, tested = deque([(START, [])]), {START}, 0
    while frontier:
        state, path = frontier.popleft()
        if state == GOAL:
            return path, tested
        for nxt, move in generate(state):
            tested += 1
            if not legal(nxt) or (smart and nxt in seen):
                continue
            seen.add(nxt)
            frontier.append((nxt, path + [move]))
        if tested > 100000:
            return None, tested

for smart in (False, True):
    path, tested = solve(smart)
    print('smart tester' if smart else 'naive tester', '-> states tested:', tested)
print('solution in', len(path), 'crossings:', path)
