# Meta-reasoning: an agent that chooses, monitors, and learns about its
# own problem-solving strategies.
import heapq, random
from collections import deque

# --- world ---
def make_maze(seed, n=12, walls=0.3):
    rnd = random.Random(seed)
    grid = [['#' if rnd.random() < walls else '.' for _ in range(n)] for _ in range(n)]
    grid[0][0] = grid[n - 1][n - 1] = '.'
    return grid

def neighbours(grid, cell):
    r, c = cell
    for nr, nc in [(r + 1, c), (r - 1, c), (r, c + 1), (r, c - 1)]:
        if 0 <= nr < len(grid) and 0 <= nc < len(grid) and grid[nr][nc] == '.':
            yield nr, nc

# --- strategies ---
def greedy(grid, start, goal, budget):
    """Fast and focused, but can wander into dead ends and long detours."""
    h = lambda x: abs(x[0] - goal[0]) + abs(x[1] - goal[1])
    frontier, seen, work = [(h(start), start, [start])], {start}, 0
    while frontier and work < budget:
        _, cell, path = heapq.heappop(frontier)
        work += 1
        if cell == goal:
            return path, work
        for n in neighbours(grid, cell):
            if n not in seen:
                seen.add(n)
                heapq.heappush(frontier, (h(n), n, path + [n]))
    return None, work

def breadth_first(grid, start, goal, budget):
    """Slow but thorough: always finds the shortest path if there is one."""
    frontier, prev, work = deque([start]), {start: None}, 0
    while frontier and work < budget:
        cell = frontier.popleft()
        work += 1
        if cell == goal:
            path = []
            while cell:
                path.append(cell)
                cell = prev[cell]
            return path[::-1], work
        for n in neighbours(grid, cell):
            if n not in prev:
                prev[n] = cell
                frontier.append(n)
    return None, work

STRATEGIES = {'greedy': greedy, 'breadth-first': breadth_first}

# --- meta ---
class MetaReasoner:
    """The meta level: a model of its own strategies (how often each one
    gives an acceptable answer, and how much work it costs), used to choose,
    to monitor, and to switch."""
    def __init__(self):
        self.stats = {s: {'tries': 1, 'good': 1, 'work': 50} for s in STRATEGIES}

    def expected_value(self, s):
        st = self.stats[s]
        return st['good'] / st['tries'] * 100 - st['work'] / st['tries'] * 0.5

    def acceptable(self, path, start, goal):
        """Monitoring: is the answer good enough? (not a huge detour)"""
        straight = abs(start[0] - goal[0]) + abs(start[1] - goal[1])
        return path is not None and len(path) - 1 <= 1.3 * straight

    def solve(self, grid, start, goal):
        order = sorted(STRATEGIES, key=self.expected_value, reverse=True)
        log = []
        for s in order:
            path, work = STRATEGIES[s](grid, start, goal, budget=200)
            ok = self.acceptable(path, start, goal) or (s == order[-1] and path)
            st = self.stats[s]
            st['tries'] += 1
            st['work'] += work
            st['good'] += bool(ok)
            log.append(f'{s} ({work} steps of work): ' + ('accepted' if ok else
                       'no path' if path is None else f'path of {len(path) - 1} rejected as a detour'))
            if ok:
                return log
        return log + ['gave up']

# --- run ---
meta = MetaReasoner()
SEEDS = [5, 122, 190, 6, 206, 214, 8, 9, 10, 16]     # a mix of easy and deceptive mazes
for k, seed in enumerate(SEEDS, 1):
    print(f'maze {k:2}: ' + ' -> '.join(meta.solve(make_maze(seed), (0, 0), (11, 11))))
for s in STRATEGIES:
    st = meta.stats[s]
    print(f'{s:13} acceptable {st["good"] - 1}/{st["tries"] - 1}, value now {meta.expected_value(s):.0f}')
