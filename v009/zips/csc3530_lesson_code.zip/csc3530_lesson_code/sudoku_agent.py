# Constraint propagation (arc consistency) on a 4x4 Sudoku.
# --- puzzle ---
PUZZLE = ['1 . . .',
          '. . 2 .',
          '. 3 . .',
          '. . . 4']
cells = [(r, c) for r in range(4) for c in range(4)]
domain = {}
for r, row in enumerate(PUZZLE):
    for c, ch in enumerate(row.split()):
        domain[(r, c)] = {int(ch)} if ch != '.' else {1, 2, 3, 4}

# --- constraints ---
def peers(cell):
    """Cells that must differ from this one: same row, column, or 2x2 box."""
    r, c = cell
    return {(rr, cc) for rr, cc in cells if (rr, cc) != cell and
            (rr == r or cc == c or (rr // 2, cc // 2) == (r // 2, c // 2))}

# --- propagate ---
def propagate(domain, verbose=True):
    """AC-3 style: whenever a cell is down to one value, remove that value
    from every peer. Repeat until nothing changes."""
    queue = [cell for cell in cells if len(domain[cell]) == 1]
    while queue:
        cell = queue.pop(0)
        (v,) = domain[cell]
        for p in peers(cell):
            if v in domain[p]:
                domain[p] = domain[p] - {v}
                if not domain[p]:
                    return False                     # contradiction
                if len(domain[p]) == 1:
                    if verbose:
                        print(f'  {p} forced to {next(iter(domain[p]))}')
                    queue.append(p)
    return True

# --- search ---
def solve(domain, depth=0):
    """Propagate; if that is not enough, guess the most constrained cell
    and propagate again (backtracking on contradiction)."""
    if not propagate(domain, verbose=depth == 0):
        return None
    open_cells = [c for c in cells if len(domain[c]) > 1]
    if not open_cells:
        return domain
    cell = min(open_cells, key=lambda c: len(domain[c]))
    for v in sorted(domain[cell]):
        trial = {k: set(s) for k, s in domain.items()}
        trial[cell] = {v}
        print('  ' * depth + f'  guess {cell} = {v}')
        result = solve(trial, depth + 1)
        if result:
            return result
    return None

solution = solve(domain)
for r in range(4):
    print(' '.join(str(next(iter(solution[(r, c)]))) for c in range(4)))
