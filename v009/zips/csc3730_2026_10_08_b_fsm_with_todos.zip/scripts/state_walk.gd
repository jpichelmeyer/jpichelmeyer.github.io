extends State
class_name Walk

@export var move_spd:float = 60.0

func enter() -> void:
	announce_enter()
	actor.AnimPlayer.play("walk")

func update_physics_process(_delta:float) -> void:
	
	var vel:Vector2 = Vector2.ZERO
	
	if Input.is_action_pressed("move_up"):
		vel += Vector2( 0,-1)
	if Input.is_action_pressed("move_down"):
		vel += Vector2( 0, 1)
	if Input.is_action_pressed("move_left"):
		vel += Vector2(-1, 0)
	if Input.is_action_pressed("move_right"):
		vel += Vector2( 1, 0)
	
	if vel.length() > 0.0:
		vel = vel.normalized()
	
	actor.velocity = move_spd * vel
	actor.move_and_slide()
