extends Node2D
class_name Agent

@onready var FSM:FiniteStateMachine = get_node("FSM")
@onready var AnimPlayer:AnimationPlayer = get_node("AnimPlayer")
@onready var StateLabel:Label = get_node("HUD/State")
