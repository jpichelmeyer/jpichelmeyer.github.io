extends Node
class_name FiniteStateMachine

'''
Setup as a Finite State Machine
'''

@export var state_initial:State
var state_current:State
var states:Dictionary = {}

#--------------- Initial setup --------------------#
func _ready() -> void:
	
	# Wait for parent node to be ready
	await owner.ready
	
	# TODO 1
	#	Collect child State nodes and populate states dictiionary
	# 	Transition to initial_state if set
	
	
#--------------- Main loop --------------------#
func _process(_delta:float) -> void:
	
	#--------- Change state based on control input --------#
	if Input.is_action_pressed("move_up") || Input.is_action_pressed("move_down") || Input.is_action_pressed("move_left") || Input.is_action_pressed("move_right"):
		# TODO 2
		#	transition to state walk
		pass
	else:
		# TODO 3
		#	transition to state idle
		pass
	
	#--------- Perform behavior based on the loaded state --------#
	
	# TODO 4
	#	Delegrate frame processing to current_state
	pass

func _physics_process(_delta:float) -> void:

	#--------- Perform behavior based on the loaded state --------#
	# TODO 5
	#	Delegrate frame processing to current_state
	pass

#--------------- Helper methods --------------------#
func transition_to(target_state_name: String) -> void:
	'''
	Call this function to change the state using its name
	'''
	
	# Retrieve new state from states dictionary
	var state_new:State = states.get(target_state_name.to_lower())
	
	# ((Guard Clause))
	if not state_new:
		print("State doesn't exist")
		return
	
	# ((Guard Clause))
	if state_new == state_current:
		return
	
	#---------- Exit the current state ----------#
	# TODO 6
	#	Call exit() on state_current
	
	#---------- Make the change -----------------#
	# TODO 7
	#	Update state_current reference
	
	#---------- Enter the new state -------------#
	# TODO 8
	#	Call enter on state_current
	
	#---------- Update visibility ---------------#
	get_parent().StateLabel.text = "State: " + target_state_name
