extends State
class_name Still

'''
Play the still animation
'''

func enter() -> void:
	announce_enter()
	actor.AnimPlayer.play("still")
