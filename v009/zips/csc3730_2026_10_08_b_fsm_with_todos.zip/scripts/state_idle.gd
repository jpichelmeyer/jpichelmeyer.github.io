extends State
class_name Idle

'''
Play 'idle' animation
'''

func enter() -> void:
	announce_enter()
	actor.AnimPlayer.play("idle")
