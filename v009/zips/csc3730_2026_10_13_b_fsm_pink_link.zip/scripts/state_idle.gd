extends State
class_name Idle

func enter() -> void:
	announce_enter()
	actor.AnimPlayer.play("idle_" + actor.facing_postfix())
