extends State
class_name StateSpin

#const SPD_SPIN:float = (5.0) * PI
const timer_max:float = 0.5
var timer_val:float = timer_max

func enter() -> void:
	announce_enter()
	timer_val = timer_max
	actor.AnimPlayer.play("spin")

func exit() -> void:
	announce_exit()
	actor.Sprite.rotation = 0.0

func update_process(delta:float) -> void:
	timer_val -= delta
	if timer_val <= 0.0:
		get_parent().transition_to("StateIdle")
