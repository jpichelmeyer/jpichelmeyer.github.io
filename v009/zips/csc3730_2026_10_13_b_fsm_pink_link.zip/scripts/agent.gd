extends Node2D
class_name Agent

enum FACING {
	EAST,
	NORTH,
	SOUTH,
	WEST
}

const FACING_postfix = {
	FACING.EAST : "e",
	FACING.NORTH : "n",
	FACING.SOUTH : "s",
	FACING.WEST : "w"
}

var facing:FACING = FACING.SOUTH

@onready var FSM:FiniteStateMachine = get_node("FSM")
@onready var AnimPlayer:AnimationPlayer = get_node("AnimPlayer")
@onready var StateLabel:Label = get_node("HUD/State")
@onready var Sprite:Sprite2D = get_node("Sprite")

func facing_postfix() -> String:
	return FACING_postfix[facing]
