extends State
class_name Walk

@export var move_spd:float = 60.0

func enter() -> void:
	announce_enter()
	actor.AnimPlayer.play("walk_" + actor.facing_postfix())

func update_physics_process(_delta:float) -> void:
	
	var vel:Vector2 = Vector2.ZERO
	
	if Input.is_action_pressed("move_up"):
		vel += Vector2( 0,-1)
		actor.facing = actor.FACING.NORTH
	if Input.is_action_pressed("move_down"):
		vel += Vector2( 0, 1)
		actor.facing = actor.FACING.SOUTH
	if Input.is_action_pressed("move_left"):
		vel += Vector2(-1, 0)
		actor.facing = actor.FACING.WEST
	if Input.is_action_pressed("move_right"):
		vel += Vector2( 1, 0)
		actor.facing = actor.FACING.EAST
	
	if vel.length() > 0.0:
		vel = vel.normalized()
		actor.AnimPlayer.play("walk_" + actor.facing_postfix())
	else:
		get_parent().transition_to("StateSpin")
	
	actor.velocity = move_spd * vel
	actor.move_and_slide()
